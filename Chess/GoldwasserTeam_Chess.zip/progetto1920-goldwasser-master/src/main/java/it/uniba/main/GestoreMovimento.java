package it.uniba.main;

import java.util.ArrayList;

/**
 * <Control> Responsabilita': Gestisce i comandi specifici del movimento dei pezzi, ricevuti in
 * input dal giocatore. Contiene la logica per l'arrocco, lungo e corto, inoltre controlla che il re
 * si muova in una posizione dove non rischia la minaccia. Permette di trovare un pezzo che si puo'
 * muovere sulla scacchiera. Conosce lo stato della partita corrente.
 *
 */
public final class GestoreMovimento {
  private static GestoreMovimento moveHandler = new GestoreMovimento();
  private Partita partitaCorrente = GestorePartita.getInstance().getPartita();
  private static final int CHAR_TO_INT = 97;
  private static final int RIGA_COL_ZERO = 0;
  private static final int RIGA_COL_UNO = 1;
  private static final int RIGA_COL_DUE = 2;
  private static final int RIGA_COL_TRE = 3;
  private static final int RIGA_COL_QUATTRO = 4;
  private static final int RIGA_COL_CINQUE = 5;
  private static final int RIGA_COL_SEI = 6;
  private static final int RIGA_COL_SETTE = 7;
  private static final int DIMENSIONE_MAX = 8;

  private InterfacciaUtente interfaccia = InterfacciaUtente.getInstance();

  private GestoreMovimento() {

  }

  public static GestoreMovimento getInstance() {
    return moveHandler;
  }

  public int getNumeroTurno() {
    return partitaCorrente.getTurno();
  }

  private Scacchiera getScacchiera() {
    return partitaCorrente.getScacchiera();
  }

  /**
   * Gestisce la mossa da eseguire, analizzando il contenuto della stringa in input ricevuta dal
   * giocatore ed invocando il metodo corretto. <br>
   * Riconosce movimenti, catture ed arrocchi
   *
   * @param input Mossa inserita dal giocatore, in notazione algebrica
   * @author m-elio, matteomannavola
   * @return azioneEseguita true se azione eseguita, false altrimenti
   */
  public boolean azione(final String input) {

    boolean azioneEseguita = false;

    if (partitaCorrente.getPartitaIniziata()) {
      Pezzo pezzo = new Pedone("nero");

      if (partitaCorrente.getTurnoBianco()) {
        switch (input.charAt(0)) {
          case 'A':
            pezzo = new Alfiere("bianco");
            break;
          case 'C':
            pezzo = new Cavallo("bianco");
            break;
          case 'T':
            pezzo = new Torre("bianco");
            break;
          case 'D':
            pezzo = new Donna("bianco");
            break;
          case 'R':
            pezzo = new Re("bianco");
            break;
          default:
            pezzo = new Pedone("bianco");
        }
      } else {
        switch (input.charAt(0)) {
          case 'A':
            pezzo = new Alfiere("nero");
            break;
          case 'C':
            pezzo = new Cavallo("nero");
            break;
          case 'T':
            pezzo = new Torre("nero");
            break;
          case 'D':
            pezzo = new Donna("nero");
            break;
          case 'R':
            pezzo = new Re("nero");
            break;
          default:
            pezzo = new Pedone("nero");
        }
      }
      if (input.matches("[a-h][1-8]")) {
        int x = Character.getNumericValue(input.charAt(RIGA_COL_UNO)) - 1;
        int y = input.charAt(RIGA_COL_ZERO) - CHAR_TO_INT;
        Posizione posNuova = new Posizione(x, y);
        muovi(getScacchiera(), 0, pezzo, posNuova, -1);

      } else if (input.matches("[a-h]x[a-h][1-8]")) {
        int x = Character.getNumericValue(input.charAt(RIGA_COL_TRE)) - 1;
        int y = input.charAt(RIGA_COL_DUE) - CHAR_TO_INT;
        int colonna = input.charAt(RIGA_COL_ZERO) - CHAR_TO_INT;
        Posizione posNuova = new Posizione(x, y);
        cattura(getScacchiera(), colonna, pezzo, posNuova, 1);

      } else if (input.matches("[a-h]x[a-h][1-8]e\\.p\\.")) {
        int x = Character.getNumericValue(input.charAt(RIGA_COL_TRE)) - 1;
        int y = input.charAt(RIGA_COL_DUE) - CHAR_TO_INT;
        int colonna = input.charAt(RIGA_COL_ZERO) - CHAR_TO_INT;
        Posizione posNuova = new Posizione(x, y);
        cattura(getScacchiera(), colonna, pezzo, posNuova, 1);

      } else if (input.matches("[TC][a-h1-8][a-h][1-8]")) {
        int x = Character.getNumericValue(input.charAt(RIGA_COL_TRE)) - 1;
        int y = input.charAt(RIGA_COL_DUE) - CHAR_TO_INT;
        Posizione posNuova = new Posizione(x, y);
        if (trovaUno(pezzo, posNuova, true)) {
          interfaccia.messaggioDisambiguazioneNonNecessaria(input);
        } else if (!disambiguazioneValida(input.charAt(RIGA_COL_UNO), pezzo)) {
          interfaccia.messaggioDisambiguazioneInadeguata();
        } else {
          if ((Character.isLetter(input.charAt(RIGA_COL_UNO)))) {
            int colonna = input.charAt(RIGA_COL_UNO) - CHAR_TO_INT;
            muovi(getScacchiera(), colonna, pezzo, posNuova, 1);
          } else {
            int riga = Character.getNumericValue(input.charAt(RIGA_COL_UNO)) - 1;
            muovi(getScacchiera(), riga, pezzo, posNuova, 0);
          }
        }

      } else if (input.matches("[TC][a-h1-8]x[a-h][1-8]")) {
        int x = Character.getNumericValue(input.charAt(RIGA_COL_QUATTRO)) - 1;
        int y = input.charAt(RIGA_COL_TRE) - CHAR_TO_INT;
        Posizione posNuova = new Posizione(x, y);
        if (trovaUno(pezzo, posNuova, false)) {
          interfaccia.messaggioDisambiguazioneNonNecessaria(input);
        } else if (!disambiguazioneValida(input.charAt(RIGA_COL_UNO), pezzo)) {
          interfaccia.messaggioDisambiguazioneInadeguata();
        } else {
          if ((Character.isLetter(input.charAt(RIGA_COL_UNO)))) {
            int colonna = input.charAt(RIGA_COL_UNO) - CHAR_TO_INT;
            cattura(getScacchiera(), colonna, pezzo, posNuova, 1);
          } else {
            int riga = Character.getNumericValue(input.charAt(1)) - 1;
            cattura(getScacchiera(), riga, pezzo, posNuova, 0);
          }
        }

      } else if (input.matches("[ATCDR][a-h][1-8]")) {
        int x = Character.getNumericValue(input.charAt(RIGA_COL_DUE)) - 1;
        int y = input.charAt(RIGA_COL_UNO) - CHAR_TO_INT;
        Posizione posNuova = new Posizione(x, y);

        if (!trovaUno(pezzo, posNuova, true)) {
          interfaccia.messaggioDisambiguazioneNecessaria();
        } else {
          muovi(getScacchiera(), 0, pezzo, posNuova, -1);
        }

      } else if (input.matches("[ATCDR]x[a-h][1-8]")) {
        int x = Character.getNumericValue(input.charAt(RIGA_COL_TRE)) - 1;
        int y = input.charAt(RIGA_COL_DUE) - CHAR_TO_INT;
        Posizione posNuova = new Posizione(x, y);

        if (!trovaUno(pezzo, posNuova, false)) {
          interfaccia.messaggioDisambiguazioneNecessaria();
        } else {
          cattura(getScacchiera(), 0, pezzo, posNuova, -1);
        }
      } else if (input.equals("0-0") || input.equals("O-O")) {
        arroccoCorto();
      } else if (input.equals("0-0-0") || input.equals("O-O-O")) {
        arroccoLungo();
      } else {
        interfaccia.messaggioMossaNonValida();
      }

      if (partitaCorrente.getMossaFatta()) {
        partitaCorrente.setMosse(input);
        azioneEseguita = true;
      }
    } else {
      interfaccia.messaggioNessunaPartita();
      azioneEseguita = false;
    }

    return azioneEseguita;

  }

  /**
   * Permette il movimento di un pezzo nella scacchiera.
   * <p>
   * Trova il pezzo che vuole eseguire il movimento e ne richiama il corrispondente mossaLegale.
   * <br>
   * Se il movimento e' legale, lo esegue. Gestisce anche movimenti disambiguati.
   *
   * @param scacchiera Scacchiera della partita corrente
   * @param coordinata Coordinata utile alla disambiguazione. Puo' essere una riga od una colonna
   * @param p Pezzo che effettua il movimento
   * @param nuova Posizione del pezzo da catturare
   * @param disambigua Specifica se il movimento e' disambiguato e, se lo e', deve essere
   *        specificata la riga o la colonna
   * @author DarioSpinosa
   */
  private void muovi(final Scacchiera scacchiera, final int coordinata, final Pezzo p,
      final Posizione nuova, final int disambigua) {

    ArrayList<Posizione> posizioni;
    Pezzo tmp = p;

    if (disambigua == -1) {
      posizioni = trovaPezzi(p);
    } else {
      posizioni = trovaPezzi(coordinata, p, disambigua);
    }

    boolean mossaEffettuata = false;

    if (posizioni.size() != 0) {

      int xNuova = nuova.getRiga();
      int yNuova = nuova.getColonna();
      Casella arrivo = scacchiera.getCasella(xNuova, yNuova);

      int i = 0;
      int x = 0;
      int y = 0;

      do {
        x = posizioni.get(i).getRiga();
        y = posizioni.get(i).getColonna();
        Casella attuale = scacchiera.getCasella(x, y);
        String simboloProprio = attuale.getPezzo().toString();

        if (arrivo.getVuota()
            && attuale.getPezzo().mossaLegale(scacchiera, posizioni.get(i), nuova)) {

          if (!reMinacciato(scacchiera, posizioni.get(i), nuova)) {

            if (disambigua == -1
                && (simboloProprio.equals("\u2654") || simboloProprio.equals("\u265A"))
                && (!controllaPosRe(nuova, posizioni.get(i)))) {
              interfaccia.messaggioReRischiaScacco();
            } else {
              tmp = scacchiera.getCasella(x, y).getPezzo();
              arrivo.setPezzo(tmp);
              attuale.setVuota(true);
              mossaEffettuata = true;
              partitaCorrente.invertiMossaFatta();
            }
          } else {
            interfaccia.messaggioReRischiaScacco();
            i = posizioni.size();
          }
        }

        i++;

      } while (i < posizioni.size() && !mossaEffettuata);
    }

    if (!mossaEffettuata) {
      interfaccia.messaggioMossaIllegale();
    }

  }

  /**
   * Permette la cattura di un pezzo nella scacchiera.
   * <p>
   * Trova il pezzo che vuole eseguire la cattura e ne richiama il corrispondente catturaLegale.
   * <br>
   * Se la cattura e' legale, la esegue. Gestisce anche catture disambiguate.
   *
   * @param scacchiera Scacchiera della partita corrente
   * @param coordinata Coordinata utile alla disambiguazione. Puo' essere una riga od una colonna
   * @param p Pezzo che effettua la cattura
   * @param nuova Posizione del pezzo da catturare
   * @param disambigua Specifica se la cattura e' disambiguata e, se lo e', deve essere specificata
   *        la riga o la colonna
   * @author DarioSpinosa
   */
  private void cattura(final Scacchiera scacchiera, final int coordinata, final Pezzo p,
      final Posizione nuova, final int disambigua) {

    ArrayList<Posizione> posizioni;
    boolean catturaEffettuata = false;
    int xNuova = nuova.getRiga();
    int yNuova = nuova.getColonna();
    Casella arrivo = scacchiera.getCasella(xNuova, yNuova);
    String coloreAvversario = "";
    String coloreProprio = "";
    Pezzo tmp = p;

    if (disambigua == -1) {
      posizioni = trovaPezzi(p);
    } else {
      posizioni = trovaPezzi(coordinata, p, disambigua);
    }

    if (posizioni.size() != 0) {
      int i = 0;
      int x = 0;
      int y = 0;

      do {

        x = posizioni.get(i).getRiga();
        y = posizioni.get(i).getColonna();
        coloreProprio = scacchiera.getCasella(x, y).getPezzo().getColore();
        Casella attuale = scacchiera.getCasella(x, y);
        String simboloProprio = attuale.getPezzo().toString();

        if (!arrivo.getVuota()) {

          coloreAvversario = scacchiera.getCasella(xNuova, yNuova).getPezzo().getColore();

          if ((!coloreAvversario.equals(coloreProprio))
              && attuale.getPezzo().catturaLegale(scacchiera, posizioni.get(i), nuova)) {

            if (!reMinacciato(scacchiera, posizioni.get(i), nuova)) {

              if ((simboloProprio.equals("\u2654") || simboloProprio.equals("\u265A"))
                  && (!controllaPosRe(nuova, posizioni.get(i)))) {
                interfaccia.messaggioReRischiaScacco();
              } else {
                partitaCorrente.setCatture(arrivo.getPezzo());
                tmp = attuale.getPezzo();
                arrivo.setPezzo(tmp);
                attuale.setVuota(true);
                catturaEffettuata = true;
                partitaCorrente.invertiMossaFatta();
              }
            } else {
              interfaccia.messaggioReRischiaScacco();
              i = posizioni.size();
            }
          }
        } else if ((simboloProprio.equals("\u2659") || simboloProprio.equals("\u265F"))) {

          if (((Pedone) (attuale.getPezzo())).enPassantLegale(scacchiera, posizioni.get(i),
              nuova)) {

            if (!reMinacciato(scacchiera, posizioni.get(i), nuova)) {

              if (partitaCorrente.getTurnoBianco()) {
                partitaCorrente.setCatture(scacchiera.getCasella(xNuova - 1, yNuova).getPezzo());
                tmp = attuale.getPezzo();
                arrivo.setPezzo(tmp);
                scacchiera.getCasella(xNuova - 1, yNuova).setVuota(true);
                attuale.setVuota(true);
                catturaEffettuata = true;
                partitaCorrente.invertiMossaFatta();
              } else {
                partitaCorrente.setCatture(scacchiera.getCasella(xNuova + 1, yNuova).getPezzo());
                tmp = attuale.getPezzo();
                arrivo.setPezzo(tmp);
                scacchiera.getCasella(xNuova + 1, yNuova).setVuota(true);
                attuale.setVuota(true);
                catturaEffettuata = true;
                partitaCorrente.invertiMossaFatta();
              }
            } else {
              interfaccia.messaggioReRischiaScacco();
              i = posizioni.size();
            }
          }

        }

        i++;

      } while (i < posizioni.size() && !catturaEffettuata);
    }

    if (!catturaEffettuata) {
      interfaccia.messaggioMossaIllegale();
    }

  }

  /**
   * Effettua l'arrocco, controllandone la validita'
   *
   * @param scacchiera Scacchiera della partita corrente
   * @param posRe Posizione iniziale del re
   * @param posTorre Posizione iniziale della torre
   * @param yReNuova Colonna di arrivo del re
   * @param yTorreNuova Colonna di arrivo della torre
   * @author matteomannavola, Yukiroby
   */
  private void arrocco(final Scacchiera scacchiera, final Posizione posRe, final Posizione posTorre,
      final int yReNuova, final int yTorreNuova) {

    int xRe = posRe.getRiga();
    int yRe = posRe.getColonna();
    int xTorre = posTorre.getRiga();
    int yTorre = posTorre.getColonna();

    Pezzo p = scacchiera.getCasella(xRe, yRe).getPezzo();
    scacchiera.getCasella(xRe, yReNuova).setPezzo(p);
    scacchiera.getCasella(xRe, yRe).setVuota(true);

    p = scacchiera.getCasella(xTorre, yTorre).getPezzo();
    scacchiera.getCasella(xTorre, yTorreNuova).setPezzo(p);
    scacchiera.getCasella(xTorre, yTorre).setVuota(true);

    partitaCorrente.invertiMossaFatta();
    ((Re) scacchiera.getCasella(xRe, yReNuova).getPezzo()).invertiPrima();
    ((Torre) (scacchiera.getCasella(xTorre, yTorreNuova).getPezzo())).invertiPrima();

  }

  /**
   * Ritorna la posizione di tutti i pezzi di un certo tipo e colore.
   * <p>
   * Controlla tutta la scacchiera
   *
   * @param p pezzo da ricercare
   * @return posizioni array delle posizioni dei pezzi di quel tipo
   * @author DarioSpinosa, Yukiroby
   */
  private ArrayList<Posizione> trovaPezzi(final Pezzo p) {

    ArrayList<Posizione> posizioni = new ArrayList<Posizione>();

    for (int i = 0; i < DIMENSIONE_MAX; i++) {

      for (int j = 0; j < DIMENSIONE_MAX; j++) {

        if (!getScacchiera().getCasella(i, j).getVuota()) {
          if ((getScacchiera().getCasella(i, j).getPezzo().toString()).equals(p.toString())) {
            posizioni.add(new Posizione(i, j));

          }
        }
      }
    }
    return posizioni;
  }

  /**
   * Ritorna la posizione di tutti i pezzi di un certo tipo e colore.
   * <p>
   * Controlla solo una colonna o riga specifica. <br>
   * Viene utilizzato a supporto di movimenti disambiguati.
   *
   * @param coordinata Riga o colonna su cui cercare i pezzi di quel tipo
   * @param p Pezzo da ricercare
   * @param isRiga Specifica se la coordinata e' una riga, una colonna o nessuna delle due
   * @return posizioni array delle posizioni dei pezzi di quel tipo
   * @author m-elio, DarioSpinosa
   */
  private ArrayList<Posizione> trovaPezzi(final int coordinata, final Pezzo p, final int isRiga) {

    ArrayList<Posizione> posizioni = new ArrayList<Posizione>();

    if (isRiga == 0) {
      for (int i = 0; i < DIMENSIONE_MAX; i++) {

        if (!getScacchiera().getCasella(coordinata, i).getVuota()) {
          if ((getScacchiera().getCasella(coordinata, i).getPezzo().toString())
              .equals(p.toString())) {
            posizioni.add(new Posizione(coordinata, i));
          }
        }

      }
    } else {
      for (int i = 0; i < DIMENSIONE_MAX; i++) {

        if (!getScacchiera().getCasella(i, coordinata).getVuota()) {
          if ((getScacchiera().getCasella(i, coordinata).getPezzo().toString())
              .equals(p.toString())) {
            posizioni.add(new Posizione(i, coordinata));
          }
        }

      }
    }
    return posizioni;
  }

  /**
   * Controlla se un solo pezzo di quel tipo puo' muoversi in una posizione specifica.
   * <p>
   * Viene utilizzato a supporto di movimenti disambiguati.
   *
   * @param pezzo Pezzo da ricercare
   * @param nuova Posizione di arrivo
   * @param isMuovi Specifica se la mossa e' un movimento o una cattura
   * @return true se un solo pezzo del tipo specificato puo' muoversi, false altrimenti
   * @author matteomannavola, FResta99
   */
  private boolean trovaUno(final Pezzo pezzo, final Posizione nuova, final boolean isMuovi) {
    ArrayList<Posizione> posizioni = trovaPezzi(pezzo);
    Posizione primoPezzo = posizioni.get(0);
    Pezzo istanza =
        getScacchiera().getCasella(primoPezzo.getRiga(), primoPezzo.getColonna()).getPezzo();
    Pezzo dummy;
    Integer numPezzi = 0;
    Boolean pezzoUnico = true;

    if ((istanza instanceof Torre) || (istanza instanceof Cavallo)) {
      if (istanza instanceof Cavallo) {
        dummy = new Cavallo("Bianco");
      } else {
        dummy = new Torre("Bianco");
      }

      if (isMuovi) {

        for (Posizione x : posizioni) {
          if (dummy.mossaLegale(getScacchiera(), x, nuova)) {
            numPezzi++;
          }
        }

      } else {

        for (Posizione x : posizioni) {
          if (dummy.catturaLegale(getScacchiera(), x, nuova)) {
            numPezzi++;
          }
        }

      }
      if (numPezzi >= 2) {
        pezzoUnico = false;
      }

    }
    return pezzoUnico;
  }

  /**
   * Verifica se il carattere usato per la disambiguazione e' compatibile con l'ambiguita' presente
   *
   * @param disambiguazione Lettera o numero usato per la disambiguazione
   * @param pezzo Pezzo su cui e' effettuata la disambiguazione
   * @return true se la disambiguazione e' valida, false altrimenti
   * @author matteomannavola
   */
  private boolean disambiguazioneValida(final char disambiguazione, final Pezzo pezzo) {
    boolean valida = true;
    ArrayList<Posizione> posizioni = trovaPezzi(pezzo);
    Posizione pos1 = posizioni.get(0);
    Posizione pos2 = posizioni.get(1);

    if (Character.isLetter(disambiguazione) && pos1.getColonna() == pos2.getColonna()) {
      valida = false;
    } else if (Character.isDigit(disambiguazione) && pos1.getRiga() == pos2.getRiga()) {
      valida = false;
    }

    return valida;
  }

  /**
   * Verifica se la prossima mossa del Re lo mette sotto scacco
   *
   * @param posRe Posizione in cui si vuole spostare il Re
   * @param posOriginale Posizione attuale del Re
   * @return true se il re si mette sotto scacco, false altrimenti
   * @author m-elio
   */
  private boolean controllaPosRe(final Posizione posRe, final Posizione posOriginale) {
    Pezzo tmp = new Pedone("bianco");
    boolean casellaOccupata = false;
    boolean legale = true;
    if (!getScacchiera().getCasella(posRe.getRiga(), posRe.getColonna()).getVuota()) {
      casellaOccupata = true;
      tmp = getScacchiera().getCasella(posRe.getRiga(), posRe.getColonna()).getPezzo();
    }
    getScacchiera().getCasella(posRe.getRiga(), posRe.getColonna()).setPezzo(
        getScacchiera().getCasella(posOriginale.getRiga(), posOriginale.getColonna()).getPezzo());
    if (posRe.getRiga() != posOriginale.getRiga()
        && posRe.getColonna() != posOriginale.getColonna()) {
      getScacchiera().getCasella(posOriginale.getRiga(), posOriginale.getColonna()).setVuota(true);
    }
    for (int i = 0; i < DIMENSIONE_MAX; i++) {
      for (int j = 0; j < DIMENSIONE_MAX; j++) {
        if (!getScacchiera().getCasella(i, j).getVuota()) {
          if (!getScacchiera().getCasella(i, j).getPezzo().getColore().equals(getScacchiera()
              .getCasella(posRe.getRiga(), posRe.getColonna()).getPezzo().getColore())) {
            if (getScacchiera().getCasella(i, j).getPezzo().catturaLegale(getScacchiera(),
                new Posizione(i, j), posRe)) {
              legale = false;
            }
          }
        }
      }
    }
    getScacchiera().getCasella(posOriginale.getRiga(), posOriginale.getColonna())
        .setPezzo(getScacchiera().getCasella(posRe.getRiga(), posRe.getColonna()).getPezzo());
    if (casellaOccupata) {
      getScacchiera().getCasella(posRe.getRiga(), posRe.getColonna()).setPezzo(tmp);
    } else {
      getScacchiera().getCasella(posRe.getRiga(), posRe.getColonna()).setVuota(true);
    }
    return legale;
  }


  /**
   * Verifica se una specifica mossa lascia il re scoperto ad una cattura nemica
   *
   * @param scacchiera Scacchiera della partita corrente
   * @param attuale Posizione del pezzo che sta cercando di muoversi o catturare
   * @param nuova Posizione dove il pezzo sta cercando di muoversi o catturare
   * @return true se il re e' minacciato, false altrimenti
   * @author DarioSpinosa
   */
  private boolean reMinacciato(final Scacchiera scacchiera, final Posizione attuale,
      final Posizione nuova) {
    int x = attuale.getRiga();
    int y = attuale.getColonna();
    int xNuova = nuova.getRiga();
    int yNuova = nuova.getColonna();
    boolean legale = false;
    Pezzo tempRe;

    if (partitaCorrente.getTurnoBianco()) {
      tempRe = new Re("bianco");
    } else {
      tempRe = new Re("nero");
    }

    ArrayList<Posizione> posizioni = trovaPezzi(tempRe);

    if (posizioni.size() != 0 && !(scacchiera.getCasella(x, y).getPezzo() instanceof Re)) {
      Pezzo temp = null;

      if (!scacchiera.getCasella(nuova.getRiga(), nuova.getColonna()).getVuota()) {
        temp = scacchiera.getCasella(xNuova, yNuova).getPezzo();
      }

      scacchiera.getCasella(xNuova, yNuova).setPezzo(scacchiera.getCasella(x, y).getPezzo());
      scacchiera.getCasella(x, y).setVuota(true);

      for (int i = 0; i < DIMENSIONE_MAX; i++) {
        for (int j = 0; j < DIMENSIONE_MAX; j++) {
          if (!getScacchiera().getCasella(i, j).getVuota()) {
            if (!getScacchiera().getCasella(i, j).getPezzo().getColore()
                .equals(getScacchiera()
                    .getCasella(posizioni.get(0).getRiga(), posizioni.get(0).getColonna())
                    .getPezzo().getColore())) {
              if (getScacchiera().getCasella(i, j).getPezzo().catturaLegale(getScacchiera(),
                  new Posizione(i, j), posizioni.get(0))) {
                legale = true;
              }
            }
          }
        }
      }

      scacchiera.getCasella(x, y).setPezzo(scacchiera.getCasella(xNuova, yNuova).getPezzo());

      if (temp != null) {
        scacchiera.getCasella(xNuova, yNuova).setPezzo(temp);
      } else {
        scacchiera.getCasella(xNuova, yNuova).setVuota(true);
      }
    }
    return legale;
  }

  /**
   * Verifica le condizioni per un arrocco corto.
   * <p>
   * Se le condizioni sono verificate, chiama il metodo arrocco
   *
   * @author matteomannavola, yukiroby
   */
  private void arroccoCorto() {
    boolean legale = false;
    int riga;
    if (partitaCorrente.getTurnoBianco()) {
      riga = RIGA_COL_ZERO;
    } else {
      riga = RIGA_COL_SETTE;
    }

    if (getScacchiera().getCasella(riga, RIGA_COL_QUATTRO).getPezzo() instanceof Re
        && getScacchiera().getCasella(riga, RIGA_COL_SETTE).getPezzo() instanceof Torre) {

      if (((Re) (getScacchiera().getCasella(riga, RIGA_COL_QUATTRO).getPezzo())).getPrimaMossa()
          && ((Torre) (getScacchiera().getCasella(riga, RIGA_COL_SETTE).getPezzo()))
              .getPrimaMossa()) {

        if (getScacchiera().getCasella(riga, RIGA_COL_CINQUE).getVuota()
            && getScacchiera().getCasella(riga, RIGA_COL_SEI).getVuota()) {

          if (controllaPosRe(new Posizione(riga, RIGA_COL_QUATTRO),
              new Posizione(riga, RIGA_COL_QUATTRO))
              && controllaPosRe(new Posizione(riga, RIGA_COL_CINQUE),
                  new Posizione(riga, RIGA_COL_QUATTRO))
              && controllaPosRe(new Posizione(riga, RIGA_COL_SEI),
                  new Posizione(riga, RIGA_COL_QUATTRO))) {

            arrocco(getScacchiera(), new Posizione(riga, RIGA_COL_QUATTRO),
                new Posizione(riga, RIGA_COL_SETTE), RIGA_COL_SEI, RIGA_COL_CINQUE);
            legale = true;
          }
        }
      }
    }

    if (!legale) {
      interfaccia.messaggioArroccoNonPossibile();
    }
  }

  /**
   * Verifica le condizioni per un arrocco lungo.
   * <p>
   * Se le condizioni sono verificate, chiama il metodo arrocco
   *
   * @author matteomannavola, yukiroby
   */
  private void arroccoLungo() {
    boolean legale = false;
    int riga;

    if (partitaCorrente.getTurnoBianco()) {
      riga = RIGA_COL_ZERO;
    } else {
      riga = RIGA_COL_SETTE;
    }

    if (getScacchiera().getCasella(riga, RIGA_COL_QUATTRO).getPezzo() instanceof Re
        && getScacchiera().getCasella(riga, RIGA_COL_ZERO).getPezzo() instanceof Torre) {

      if (((Re) (getScacchiera().getCasella(riga, RIGA_COL_QUATTRO).getPezzo())).getPrimaMossa()
          && ((Torre) (getScacchiera().getCasella(riga, RIGA_COL_ZERO).getPezzo()))
              .getPrimaMossa()) {

        if (getScacchiera().getCasella(riga, RIGA_COL_UNO).getVuota()
            && getScacchiera().getCasella(riga, RIGA_COL_DUE).getVuota()
            && getScacchiera().getCasella(riga, RIGA_COL_TRE).getVuota()) {

          if (controllaPosRe(new Posizione(riga, RIGA_COL_QUATTRO),
              new Posizione(riga, RIGA_COL_QUATTRO))
              && controllaPosRe(new Posizione(riga, RIGA_COL_TRE),
                  new Posizione(riga, RIGA_COL_QUATTRO))
              && controllaPosRe(new Posizione(riga, RIGA_COL_DUE),
                  new Posizione(riga, RIGA_COL_QUATTRO))) {

            arrocco(getScacchiera(), new Posizione(riga, RIGA_COL_QUATTRO),
                new Posizione(riga, RIGA_COL_ZERO), RIGA_COL_DUE, RIGA_COL_TRE);
            legale = true;
          }
        }
      }
    }

    if (!legale) {
      interfaccia.messaggioArroccoNonPossibile();
    }

  }

}
