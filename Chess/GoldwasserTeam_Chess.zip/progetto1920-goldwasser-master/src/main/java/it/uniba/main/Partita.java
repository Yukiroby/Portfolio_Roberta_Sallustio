package it.uniba.main;


import java.util.ArrayList;


/**
 * <Entity> Responsabilita': Rappresenta una partita nel gioco degli scacchi. Garantisce
 * l'alternanza ciclica tra i giocatori. Include la lista delle mosse e delle catture avvenute nella
 * partita. Conosce il numero del turno corrente e lo stato della scacchiera.
 */
public final class Partita {
  private boolean partitaIniziata = false;
  private boolean turnoBianco;
  private boolean mossaFatta;
  private Scacchiera scacchiera;
  private int numeroTurno = 0;
  private ArrayList<Pezzo> catture;
  private ArrayList<String> storico;


  public Partita() {
    turnoBianco = true;
    scacchiera = new Scacchiera();
    catture = new ArrayList<Pezzo>();
    storico = new ArrayList<>();
  }


  public boolean getPartitaIniziata() {
    return partitaIniziata;
  }


  public void setPartitaIniziata(final boolean iniziata) {
    partitaIniziata = iniziata;
  }


  /**
   * La variabile "turnoBianco" e' utilizzata per stabilire il turno dei giocatore corrente
   *
   * @return true se il turno corrente e' del giocatore bianco, false altrimenti
   */
  public boolean getTurnoBianco() {
    return turnoBianco;
  }


  /**
   * @return true se la mossa effettuata e' valida, false altrimenti
   */
  public boolean getMossaFatta() {
    return mossaFatta;
  }


  /**
   * @param p Pezzo catturato da aggiungere alla lista delle catture
   */
  public void setCatture(final Pezzo p) {
    catture.add(p);
  }


  /**
   * @param mossa mossa in notazione algebrica da aggiungere allo storico
   */
  public void setMosse(final String mossa) {
    storico.add(mossa);
  }


  /**
   * Inverte il valore della variabile mossaFatta
   * <p>
   * L'attributo e' impostato a true dopo aver effettuato con successo una mossa Viene utilizzato
   * per i metodi di cattura e movimento
   */
  public void invertiMossaFatta() {
    mossaFatta = !mossaFatta;
  }


  public Scacchiera getScacchiera() {
    return scacchiera;
  }


  public int getTurno() {
    return numeroTurno;
  }


  public ArrayList<Pezzo> getCatture() {
    return catture;
  }


  public ArrayList<String> getStorico() {
    return storico;
  }


  /**
   * Inizia una nuova partita. Costruisce una scacchiera e gestisce la partita rispettando
   * l'alternanza tra i giocatori
   * <p>
   * Tramite il controllo di mossaFatta e' possibile chiedere ciclicamente un input al giocatore in
   * uno stesso turno, fino a che viene effettuata una mossa valida semanticamente. Garantisce
   * l'alternanza tra i giocatori invertendo il valore di turnoBianco, fino alla fine della partita
   */
  public void inizia() {
    partitaIniziata = true;
    turnoBianco = true;
    scacchiera = new Scacchiera();
    catture = new ArrayList<Pezzo>();
    storico = new ArrayList<>();


    while (partitaIniziata) {


      if (turnoBianco) {
        System.out.println("-Turno del Bianco-");
      } else {
        System.out.println("-Turno del Nero-");
      }


      mossaFatta = false;
      while (!mossaFatta) {
        InterfacciaUtente.getInstance().input();
      }


      numeroTurno++;
      turnoBianco = !turnoBianco;
    }
  }
}


