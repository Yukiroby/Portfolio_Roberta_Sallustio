package it.uniba.main;
import java.util.Scanner;

/**
 * <Boundary> Responsabilita': Acquisisce input da tastiera.
 */
public final class InputTastiera {
	private static InputTastiera tastiera = new InputTastiera();
	private Scanner scanner = new Scanner(System.in, "UTF-8");

	private InputTastiera() {

	}

	public static InputTastiera getInstance() {
		return tastiera;
	}

	/**
	 * @return stringa in input da tastiera, senza spazi iniziali e finali
	 */
	public String input() {
		return scanner.nextLine().trim();
	}

	public void close() {
		scanner.close();
	}
}
