package it.uniba.main;

/**
 * <Entity> Responsabilita': Rappresenta la scacchiera usata nel gioco degli scacchi. Permette di
 * visualizzare la scacchiera su schermo. Conosce lo stato delle caselle che la costituiscono.
 */

public class Scacchiera {
  private Casella[][] scacchiera = new Casella[DIMENSIONE_MAX][DIMENSIONE_MAX];
  private static final int RIGA_COL_ZERO = 0;
  private static final int RIGA_COL_UNO = 1;
  private static final int RIGA_COL_DUE = 2;
  private static final int RIGA_COL_TRE = 3;
  private static final int RIGA_COL_QUATTRO = 4;
  private static final int RIGA_COL_CINQUE = 5;
  private static final int RIGA_COL_SEI = 6;
  private static final int RIGA_COL_SETTE = 7;
  private static final int DIMENSIONE_MAX = 8;

  /**
   * Crea una scacchiera, assegnando i pezzi ai posti legittimi
   */
  public Scacchiera() {

    for (int i = 0; i < DIMENSIONE_MAX; i++) {
      for (int j = 0; j < DIMENSIONE_MAX; j++) {
        scacchiera[i][j] = new Casella();
      }
    }

    for (int j = 0; j < DIMENSIONE_MAX; j++) {
      scacchiera[RIGA_COL_UNO][j].setPezzo(new Pedone("bianco"));
      scacchiera[RIGA_COL_SEI][j].setPezzo(new Pedone("nero"));
    }
    scacchiera[RIGA_COL_ZERO][RIGA_COL_ZERO].setPezzo(new Torre("bianco"));
    scacchiera[RIGA_COL_ZERO][RIGA_COL_SETTE].setPezzo(new Torre("bianco"));
    scacchiera[RIGA_COL_SETTE][RIGA_COL_ZERO].setPezzo(new Torre("nero"));
    scacchiera[RIGA_COL_SETTE][RIGA_COL_SETTE].setPezzo(new Torre("nero"));

    scacchiera[RIGA_COL_ZERO][RIGA_COL_UNO].setPezzo(new Cavallo("bianco"));
    scacchiera[RIGA_COL_ZERO][RIGA_COL_SEI].setPezzo(new Cavallo("bianco"));
    scacchiera[RIGA_COL_SETTE][RIGA_COL_UNO].setPezzo(new Cavallo("nero"));
    scacchiera[RIGA_COL_SETTE][RIGA_COL_SEI].setPezzo(new Cavallo("nero"));

    scacchiera[RIGA_COL_ZERO][RIGA_COL_DUE].setPezzo(new Alfiere("bianco"));
    scacchiera[RIGA_COL_ZERO][RIGA_COL_CINQUE].setPezzo(new Alfiere("bianco"));
    scacchiera[RIGA_COL_SETTE][RIGA_COL_DUE].setPezzo(new Alfiere("nero"));
    scacchiera[RIGA_COL_SETTE][RIGA_COL_CINQUE].setPezzo(new Alfiere("nero"));

    scacchiera[RIGA_COL_ZERO][RIGA_COL_QUATTRO].setPezzo(new Re("bianco"));
    scacchiera[RIGA_COL_ZERO][RIGA_COL_TRE].setPezzo(new Donna("bianco"));

    scacchiera[RIGA_COL_SETTE][RIGA_COL_QUATTRO].setPezzo(new Re("nero"));
    scacchiera[RIGA_COL_SETTE][RIGA_COL_TRE].setPezzo(new Donna("nero"));

  }

  public Scacchiera(final boolean vuoto) {

    for (int i = 0; i < DIMENSIONE_MAX; i++) {
      for (int j = 0; j < DIMENSIONE_MAX; j++) {
        scacchiera[i][j] = new Casella();
      }
    }
  }

  /**
   * @param x Riga della scacchiera
   * @param y Colonna della scacchiera
   * @return casella nella posizione specificata
   */
  public Casella getCasella(final int x, final int y) {
    return scacchiera[x][y];
  }


}
