/*
 * To change this license header, choose License Headers in Project Properties. To change this
 * template file, choose Tools | Templates and open the template in the editor.
 */
package it.uniba.main;

/**
 * <Entity> Responsabilita': Rappresenta un pezzo generico degli scacchi.
 *
 */
public abstract class Pezzo {
  private String colore;
  private String simbolo;

  public Pezzo() {

  }

  /**
   * @return colore puo' essere "bianco" o "nero"
   */
  protected String getColore() {
    return this.colore;
  }

  /**
   * @return simbolo Simbolo del pezzo in unicode (UTF-8)
   */
  protected String getSimbolo() {
    return this.simbolo;
  }

  /**
   * @param parColore colore del pezzo generico
   */
  protected void setColore(final String parColore) {
    if (parColore == null) {
      return;
    }
    if (!parColore.equals("bianco") && !parColore.equals("nero")) {
      return;
    }
    this.colore = parColore;
  }

  /**
   * @param parSimbolo simbolo Unicode del pezzo (UTF-8)
   */
  protected void setSimbolo(final String parSimbolo) {
    if (parSimbolo == null) {
      return;
    }
    this.simbolo = parSimbolo;
  }

  /**
   * Restituisce il simbolo di un generico pezzo degli scacchi
   * <p>
   * Viene usato nelle stampe
   *
   * @return simbolo Simbolo del pezzo in unicode (UTF-8)
   */
  @Override
  public String toString() {
    return this.simbolo;
  }

  public abstract boolean mossaLegale(Scacchiera scacchiera, Posizione attuale, Posizione nuova);

  public abstract boolean catturaLegale(Scacchiera scacchiera, Posizione attuale, Posizione nuova);

}
