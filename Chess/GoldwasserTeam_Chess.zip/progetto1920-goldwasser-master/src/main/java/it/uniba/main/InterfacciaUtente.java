package it.uniba.main;

import java.util.ListIterator;

/**
 * <Boundary> Responsabilita': Riceve l'input del giocatore, la cui gestione e' successivamente
 * delegata a GestorePartita o GestoreMovimento. Controlla la correttezza sintattica di mosse e
 * comandi. Gestisce i messaggi di output.
 *
 */
public final class InterfacciaUtente {
  private static InterfacciaUtente interfaccia = new InterfacciaUtente();
  private String stringaInput;
  private boolean esci = false;
  private static final int DIMENSIONE_MAX = 8;

  private InterfacciaUtente() {

  }

  public static InterfacciaUtente getInstance() {
    return interfaccia;
  }

  /**
   * Verifica se un input e' valido e lo passa al gestore corretto
   * <p>
   * Prende un input e lo salva ciclicamente nell'attributo stringaInput fino a ottenere un comando
   * valido (play, board...) o una mossa sintatticamente corretta secondo la notazione algebrica.
   * Successivamente delega la gestione di tale comando al gestore corrispondente
   */
  public void input() {
    int rispostaValida = 0;
    do {

      System.out.print("-> ");
      stringaInput = InputTastiera.getInstance().input();
      rispostaValida = controlla();
      if (rispostaValida != 1 && rispostaValida != 2) {
        messaggioComandoNonRiconosciuto();
      }
    } while (rispostaValida != 1 && rispostaValida != 2);

    if (rispostaValida == 1) {
      GestorePartita.getInstance().evento(stringaInput);
    } else {
      GestoreMovimento.getInstance().azione(stringaInput);
    }
  }

  /**
   * Controlla che il valore corrente di "stringaInput" sia un comando valido o una mossa
   * sintatticamente corretta
   *
   * @return 1 se e' un comando, 2 se e' una mossa, 0 altrimenti
   */
  private int controlla() {
    int tipo = 0;
    if (stringaInput.equals("play") || stringaInput.equals("board")
        || stringaInput.equals("captures") || stringaInput.equals("moves")
        || stringaInput.equals("quit") || stringaInput.equals("help")) {
      tipo = 1;
    } else if (stringaInput.equals("0-0-0") || stringaInput.equals("0-0")
        || stringaInput.equals("O-O-O") || stringaInput.equals("O-O")
        || stringaInput.matches("[RDTAC]?[a-h][1-8]|[RDTAC|a-h]x[a-h][1-8]|"
            + "[RDTAC][a-h1-8][x]?[a-h][1-8]|[a-h]x[a-h][1-8]e\\.p\\.")) {
      tipo = 2;
    }
    return tipo;
  }

  /**
   * @return stringaInput contiene l'input del giocatore
   */
  public String getStringaInput() {
    return stringaInput;
  }

  /**
   * Restituisce vero se l'utente ha scelto di chiudere il gioco
   *
   * @return true se il gioco deve essere chiuso, false altrimenti
   */
  public boolean getEsci() {
    return esci;
  }

  /**
   * Imposta il valore della variabile "esci" Se "esci" diventa true, il ciclo nel main del
   * programma termina, chiudendo il gioco.
   *
   * @param value true o false
   */
  public void setEsci(final boolean value) {
    esci = value;
  }

  /**
   * Stampa a video la scacchiera al giocatore. Rappresenta i pezzi con i caratteri Unicode
   * 
   * @param scacchiera scacchiera corrente
   */
  public void visualizzaScacchiera(final Scacchiera scacchiera) {

    System.out.println("---------------------------------------");

    for (int i = DIMENSIONE_MAX; i >= -1; i--) {

      if (i == -1 || i == DIMENSIONE_MAX) {

        System.out.println("\u2002\u2002\u0020|\u2002A\u2002|\u2002B\u2002|\u2002C\u2002"
            + "|\u2002D\u2002|\u2002E\u2002|\u2002F\u2002" + "|\u2002G\u2002|\u2002H\u2002|\u3000");
        System.out.println("---------------------------------------");

      } else {
        int indice = i + 1;
        System.out.print("\u2002" + indice + "\u2002|");

        for (int j = 0; j <= DIMENSIONE_MAX - 1; j++) {

          if (scacchiera.getCasella(i, j).getVuota()) {

            System.out.print("\u2002" + scacchiera.getCasella(i, j).toString() + "\u2002|");

          } else {

            System.out
                .print("\u2002" + scacchiera.getCasella(i, j).getPezzo().toString() + "\u2002|");

          }

        }

        System.out.print("\u2002" + indice + "\n");
        System.out.println("---------------------------------------");

      }

    }

  }

  /**
   * Stampa a video i comandi disponibili nel gioco
   *
   * @author paolodamianomanzoni
   */
  public void help() {
    System.out.println("---------HELP---------");
    System.out.println("|\t play        |");
    System.out.println("|\t board       |");
    System.out.println("|\t moves       |");
    System.out.println("|\t captures    |");
    System.out.println("|\t quit        |");
    System.out.println("----------------------");
  }

  /**
   * Stampa tutte le mosse giocate durante la partita. <br>
   * Le mosse sono stampate in notazione algebrica. <br>
   * Ogni riga contiene la mossa del giocatore bianco e nero
   *
   * @param partita partita corrente
   *
   * @author m-elio
   */
  public void stampaStorico(final Partita partita) {
    int numeroMossa = 0;
    int numeroTurno = 1;
    System.out.println("Lista mosse giocate:");
    System.out.print(numeroTurno + ". ");
    for (String mossa : partita.getStorico()) {
      numeroMossa++;
      System.out.print(mossa + " ");
      if (((numeroMossa % 2) == 0) && (partita.getStorico().size() != numeroMossa)) {
        numeroTurno++;
        System.out.println();
        System.out.print(numeroTurno + ". ");
      }
    }
    System.out.println();
  }

  /**
   * Stampa a video le catture del giocatore bianco e nero. <br>
   * I pezzi sono rappresentiati dal loro carattere Unicode
   *
   * @param partita partita corrente
   */
  public void stampaCatture(final Partita partita) {
    ListIterator<Pezzo> lit = partita.getCatture().listIterator();
    Pezzo pezzo;
    System.out.println("Lista catture bianchi");
    while (lit.hasNext()) {
      pezzo = lit.next();
      if (pezzo.getColore().equals("nero")) {
        System.out.print(pezzo.toString());
      }
    }
    lit = partita.getCatture().listIterator();
    System.out.println();
    System.out.println("Lista catture neri");
    while (lit.hasNext()) {
      pezzo = lit.next();
      if (pezzo.getColore().equals("bianco")) {
        System.out.print(pezzo.toString());
      }
    }
    System.out.println();
  }

  public void messaggioBenvenuto() {
    System.out.println("Benvenuto in Scacchi a linea di comando!");
    System.out.print("Digita \"help\" per visualizzare i comandi ");
    System.out.println("oppure \"play\" per incominciare a giocare");
  }

  public void messaggioComandoNonRiconosciuto() {
    System.out.println("Comando non riconosciuto");
  }

  public void messaggioDisambiguazioneNonNecessaria(final String input) {
    System.out.println("Mossa illegale: disambiguazione non necessaria");
    System.out.println("Forse intendevi: " + input.substring(0, 1).concat(input.substring(2)));
  }

  public void messaggioDisambiguazioneInadeguata() {
    System.out.println("Mossa illegale: disambiguazione inadeguata");
  }

  public void messaggioDisambiguazioneNecessaria() {
    System.out.println("Mossa illegale: disambiguazione necessaria");
  }

  public void messaggioMossaNonValida() {
    System.out.println("Mossa non valida");
  }

  public void messaggioNessunaPartita() {
    System.out.println("Nessuna partita in corso");
  }

  public void messaggioMossaIllegale() {
    System.out.println("Mossa illegale");
  }

  public void messaggioArroccoNonPossibile() {
    System.out.println("Arrocco non possibile");
  }

  public void messaggioReRischiaScacco() {
    System.out.println("Il re sarebbe sotto scacco: ");
  }

}
