package it.uniba.main;

/**
 * <Entity> Responsabilita': Rappresenta il pezzo degli scacchi "Alfiere". Verifica la correttezza
 * delle mosse di cattura e movimento.
 *
 *
 */
public final class Alfiere extends Pezzo {
  private static final String BIANCO = "\u2657";
  private static final String NERO = "\u265D";

  /**
   * Crea un nuovo pezzo di tipo Alfiere
   *
   * @param colore "bianco" o "nero", case unsensitive
   * @author FResta99, paolodamianomanzoni
   */
  public Alfiere(final String colore) {
    if (colore.equalsIgnoreCase("bianco")) {
      setColore(colore);
      setSimbolo(BIANCO);
    } else if (colore.equalsIgnoreCase("nero")) {
      setColore(colore);
      setSimbolo(NERO);
    } else {
      setColore("bianco");
      setSimbolo(BIANCO);
    }
  }

  /**
   * Controlla se una mossa di movimento dell'alfiere e' legale o meno <br>
   * Richiama il metodo movimentoGenerico poiche' cattura e movimento dell'Alfiere sono simili
   *
   * @param scacchiera Scacchiera della partita corrente
   * @param attuale Posizione attuale dell'alfiere
   * @param nuova Posizione di arrivo dell'alfiere
   * @return true se la mossa e' legale, false altrimenti
   * @author DarioSpinosa
   */
  @Override
  public boolean mossaLegale(final Scacchiera scacchiera, final Posizione attuale,
      final Posizione nuova) {
    return movimentoGenerico(scacchiera, attuale, nuova);
  }

  /**
   * Controlla se una cattura dell'alfiere e' legale o meno <br>
   * Richiama il metodo movimentoGenerico poiche' cattura e movimento dell'Alfiere sono simili
   *
   * @param scacchiera Scacchiera della partita corrente
   * @param attuale Posizione attuale dell'alfiere
   * @param nuova Posizione di cattura dell'alfiere
   * @return true se la cattura e' legale, false altrimenti
   * @author DarioSpinosa
   */
  @Override
  public boolean catturaLegale(final Scacchiera scacchiera, final Posizione attuale,
      final Posizione nuova) {
    return movimentoGenerico(scacchiera, attuale, nuova);
  }

  /**
   * Controlla se il movimento dell'alfiere sia valido
   *
   * @param scacchiera scacchiera della partita corrente
   * @param attuale posizione attuale dell'alfiere
   * @param nuova posizione di cattura dell'alfiere
   * @return "true" se la mossa e' legale, "false" altrimenti
   * @author DarioSpinosa
   */
  private boolean movimentoGenerico(final Scacchiera scacchiera, final Posizione attuale,
      final Posizione nuova) {
    boolean legale = false;
    int xNuova = nuova.getRiga();
    int yNuova = nuova.getColonna();
    int x = attuale.getRiga();
    int y = attuale.getColonna();

    if ((Math.abs(xNuova - x) == Math.abs(yNuova - y))) {

      legale = true;
      int differenzaRiga = xNuova - x;
      int differenzaColonna = yNuova - y;
      boolean rigaPositiva = false;
      boolean colonnaPositiva = false;
      int contatore = 1;

      if (differenzaRiga > 0) {
        rigaPositiva = true;
      }

      if (differenzaColonna > 0) {
        colonnaPositiva = true;
      }

      if (rigaPositiva && colonnaPositiva) { // ALTO a sinistra

        while (legale && contatore < Math.abs(differenzaRiga)) {

          x++;
          y++;

          if (!(scacchiera.getCasella(x, y).getVuota())) {
            legale = false;
          }

          contatore++;

        }

      } else if (!rigaPositiva && colonnaPositiva) { // basso a destra

        while (legale && contatore < Math.abs(differenzaRiga)) {

          x--;
          y++;

          if (!(scacchiera.getCasella(x, y).getVuota())) {
            legale = false;
          }

          contatore++;

        }

      } else if (rigaPositiva && !colonnaPositiva) { // alto a destra

        while (legale && contatore < Math.abs(differenzaRiga)) {

          x++;
          y--;

          if (!(scacchiera.getCasella(x, y).getVuota())) {
            legale = false;
          }

          contatore++;

        }

      } else if (!rigaPositiva && !colonnaPositiva) { // basso a sinistra

        while (legale && contatore < Math.abs(differenzaRiga)) {

          x--;
          y--;

          if (!(scacchiera.getCasella(x, y).getVuota())) {
            legale = false;
          }

          contatore++;

        }

      }
    }

    return legale;
  }
}
