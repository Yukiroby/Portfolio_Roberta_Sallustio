package it.uniba.main;

/**
 * <Entity> Responsabilita': Rappresenta il pezzo degli scacchi "Torre". Verifica la correttezza
 * delle mosse di cattura e movimento.
 *
 *
 */
public final class Torre extends Pezzo {
  private static final String BIANCO = "\u2656";
  private static final String NERO = "\u265C";
  private boolean primaMossa = true;

  /**
   * Crea un nuovo pezzo di tipo Torre
   *
   * @param colore "bianco" o "nero", case unsensitive
   * @author FResta99, paolodamianomanzoni
   */
  public Torre(final String colore) {
    if (colore.equalsIgnoreCase("bianco")) {
      setColore(colore);
      setSimbolo(BIANCO);
    } else if (colore.equalsIgnoreCase("nero")) {
      setColore(colore);
      setSimbolo(NERO);
    } else {
      setColore("bianco");
      setSimbolo(BIANCO);
    }
  }

  /**
   * Stabilisce se la torre ha effettuato la sua prima mossa. <br>
   * Viene utilizzato nel controllo per l'arrocco
   *
   * @return true se la torre e' stata mossa, false altrimenti
   */
  public boolean getPrimaMossa() {
    return primaMossa;
  }

  public void invertiPrima() {
    primaMossa = !primaMossa;
  }

  /**
   * Controlla se un generica mossa della torre, cattura o movimento, sia legale o meno
   *
   * @param scacchiera Scacchiera della partita corrente
   * @param attuale Posizione attuale della torre
   * @param nuova Posizione di arrivo della torre
   * @return true se la mossa e' legale, false altrimenti
   * @author FResta99
   */
  private boolean movimentoGenerico(final Scacchiera scacchiera, final Posizione attuale,
      final Posizione nuova) {

    boolean legale = false;
    int attualeX = nuova.getRiga() - attuale.getRiga();
    int attualeY = nuova.getColonna() - attuale.getColonna();

    if ((Math.abs(attualeX) == 1 && attualeY == 0) || (attualeX == 0 && Math.abs(attualeY) == 1)) {
      legale = true;
    } else if (attualeX > 0 && attualeY == 0) {

      for (int i = nuova.getRiga() - 1; i != attuale.getRiga(); i--) {
        if (scacchiera.getCasella(i, attuale.getColonna()).getVuota()) {
          legale = true;
        } else {
          legale = false;
          break;
        }
      }

    } else if (attualeX < 0 && attualeY == 0) {

      for (int i = nuova.getRiga() + 1; i != attuale.getRiga(); i++) {
        if (scacchiera.getCasella(i, attuale.getColonna()).getVuota()) {
          legale = true;
        } else {
          legale = false;
          break;
        }
      }

    } else if (attualeX == 0 && attualeY > 0) {

      for (int i = nuova.getColonna() - 1; i != attuale.getColonna(); i--) {
        if (scacchiera.getCasella(attuale.getRiga(), i).getVuota()) {
          legale = true;
        } else {
          legale = false;
          break;
        }
      }

    } else if (attualeX == 0 && attualeY < 0) {

      for (int i = nuova.getColonna() + 1; i != attuale.getColonna(); i++) {
        if (scacchiera.getCasella(attuale.getRiga(), i).getVuota()) {
          legale = true;
        } else {
          legale = false;
          break;
        }
      }

    }

    if (legale && primaMossa) {
      primaMossa = false;
    }

    return legale;
  }

  /**
   * Controlla se una mossa di movimento della torre e' legale o meno <br>
   * Richiama il metodo movimentoGenerico poiche' cattura e movimento della torre sono simili
   *
   * @param scacchiera Scacchiera della partita corrente
   * @param attuale Posizione attuale della torre
   * @param nuova Posizione di arrivo della torre
   * @return true se la mossa e' legale, false altrimenti
   * @author FResta99
   */
  @Override
  public boolean mossaLegale(final Scacchiera scacchiera, final Posizione attuale,
      final Posizione nuova) {
    return movimentoGenerico(scacchiera, attuale, nuova);
  }

  /**
   * Controlla se una cattura della torre e' legale o meno <br>
   * Richiama il metodo movimentoGenerico poiche' cattura e movimento della torre sono simili
   *
   * @param scacchiera Scacchiera della partita corrente
   * @param attuale Posizione attuale della torre
   * @param nuova Posizione di arrivo della torre
   * @return true se la mossa e' legale, false altrimenti
   * @author FResta99
   */
  @Override
  public boolean catturaLegale(final Scacchiera scacchiera, final Posizione attuale,
      final Posizione nuova) {
    return movimentoGenerico(scacchiera, attuale, nuova);
  }

}

