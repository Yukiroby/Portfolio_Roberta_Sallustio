package it.uniba.main;

/**
 * <Entity> Responsabilita': Rappresenta il pezzo degli scacchi "Cavallo". Verifica la correttezza
 * delle mosse di cattura e movimento.
 *
 *
 */
public final class Cavallo extends Pezzo {
  private static final String BIANCO = "\u2658";
  private static final String NERO = "\u265E";

  /**
   * Crea un nuovo pezzo di tipo Cavallo
   *
   * @param colore "bianco" o "nero", case unsensitive
   * @author FResta99, paolodamianomanzoni
   */
  public Cavallo(final String colore) {

    if (colore.equalsIgnoreCase("bianco")) {
      setColore(colore);
      setSimbolo(BIANCO);
    } else if (colore.equalsIgnoreCase("nero")) {
      setColore(colore);
      setSimbolo(NERO);
    } else {
      setColore("bianco");
      setSimbolo(BIANCO);
    }

  }

  /**
   * Controlla se una mossa di movimento del cavallo e' legale o meno <br>
   * Richiama il metodo movimentoGenerico poiche' cattura e movimento del cavallo sono simili
   *
   * @param scacchiera Scacchiera della partita corrente
   * @param attuale Posizione attuale dell cavallo
   * @param nuova Posizione di arrivo del cavallo
   * @return true se la mossa e' legale, false altrimenti
   * @author sonnante497, paolodamianomanzoni
   */
  @Override
  public boolean mossaLegale(final Scacchiera scacchiera, final Posizione attuale,
      final Posizione nuova) {
    return movimentoGenerico(scacchiera, attuale, nuova);
  }

  /**
   * Controlla se una cattura del cavallo e' legale o meno <br>
   * Richiama il metodo movimentoGenerico poiche' cattura e movimento del cavallo sono simili
   *
   * @param scacchiera Scacchiera della partita corrente
   * @param attuale Posizione attuale dell cavallo
   * @param nuova Posizione di cattura del cavallo
   * @return true se la cattura e' legale, false altrimenti
   * @author sonnante497, paolodamianomanzoni
   */
  @Override
  public boolean catturaLegale(final Scacchiera scacchiera, final Posizione attuale,
      final Posizione nuova) {
    return movimentoGenerico(scacchiera, attuale, nuova);
  }

  /**
   * Controlla se un generica mossa del cavallo, cattura o movimento, sia legale o meno
   *
   * @param scacchiera Scacchiera della partita corrente
   * @param attuale Posizione attuale dell cavallo
   * @param nuova Posizione di arrivo del cavallo
   * @return true se la mossa e' legale, false altrimenti
   * @author sonnante497, paolodamianomanzoni
   */
  private boolean movimentoGenerico(final Scacchiera scacchiera, final Posizione attuale,
      final Posizione nuova) {
    boolean legale = false;
    int differenzaX = nuova.getRiga() - attuale.getRiga();
    int differenzaY = nuova.getColonna() - attuale.getColonna();

    if ((Math.abs(differenzaX) == 2 && Math.abs(differenzaY) == 1)
        || (Math.abs(differenzaX) == 1 && Math.abs(differenzaY) == 2)) {
      legale = true;
    }

    return legale;
  }
}
