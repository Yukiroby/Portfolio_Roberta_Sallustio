/*
 * To change this license header, choose License Headers in Project Properties. To change this
 * template file, choose Tools | Templates and open the template in the editor.
 */
package it.uniba.main;

/**
 * <Entity> Responsabilita': Rappresenta il pezzo degli scacchi "Pedone". Verifica la correttezza
 * delle mosse di cattura e movimento, incluso en passant.
 *
 */
public final class Pedone extends Pezzo {
  private static final String BIANCO = "\u2659";
  private static final String NERO = "\u265F";
  private boolean primaMossa = true;
  private int primaMossaLunga = 0;

  /**
   * Crea un nuovo pezzo di tipo Pedone
   *
   * @param colore "bianco" o "nero", case unsensitive
   * @author FResta99, paolodamianomanzoni
   */
  public Pedone(final String colore) {
    if (colore.equalsIgnoreCase("bianco")) {
      setColore(colore);
      setSimbolo(BIANCO);
    } else if (colore.equalsIgnoreCase("nero")) {
      setColore(colore);
      setSimbolo(NERO);
    } else {
      setColore("bianco");
      setSimbolo(BIANCO);
    }
  }

  /**
   * Restituisce il numero del turno in cui il pedone si e' mosso di due caselle
   *
   * @return primaMossaLunga: numero del turno
   */
  public int getPrimaMossaLunga() {
    return primaMossaLunga;
  }

  /**
   * Controlla se una mossa di movimento del pedone e' legale o meno
   *
   * @param scacchiera Scacchiera della partita corrente
   * @param attuale Posizione attuale del pedone
   * @param nuova Posizione di arrivo del pedone
   * @return true se la mossa e' legale, false altrimenti
   * @author DarioSpinosa
   */
  @Override
  public boolean mossaLegale(final Scacchiera scacchiera, final Posizione attuale,
      final Posizione nuova) {

    boolean legale = false;
    int x = attuale.getRiga();
    int y = attuale.getColonna();
    int xNuova = nuova.getRiga();
    int yNuova = nuova.getColonna();

    if (primaMossa) {

      if (this.getColore().equals("bianco")) {

        if (xNuova - x <= 2 && xNuova - x >= 1 && yNuova == y) {

          if (scacchiera.getCasella(x + 1, y).getVuota()) {

            legale = true;
            primaMossa = false;

            if (Math.abs(xNuova - x) == 2) {
              primaMossaLunga = GestoreMovimento.getInstance().getNumeroTurno();
            }
          }
        }
      } else {
        if (x - xNuova <= 2 && x - xNuova >= 1 && yNuova == y) {

          if (scacchiera.getCasella(x - 1, y).getVuota()) {

            legale = true;
            primaMossa = false;

            if (Math.abs(xNuova - x) == 2) {
              primaMossaLunga = GestoreMovimento.getInstance().getNumeroTurno();
            }
          }
        }
      }
    } else {

      if (this.getColore().equals("bianco")) {
        if (xNuova - x == 1 && yNuova == y) {
          if (scacchiera.getCasella(x + 1, y).getVuota()) {
            legale = true;
          }
        }

      } else {
        if (x - xNuova == 1 && yNuova == y) {
          if (scacchiera.getCasella(x - 1, y).getVuota()) {
            legale = true;
          }
        }
      }

    }
    return legale;
  }

  /**
   * Controlla se la cattura del pedone e' legale o meno
   *
   * @param scacchiera Scacchiera della partita corrente
   * @param attuale Posizione attuale del pedone
   * @param nuova Posizione di cattura del pedone
   * @return true se la cattura e' legale, false altrimenti
   * @author DarioSpinosa
   */
  @Override
  public boolean catturaLegale(final Scacchiera scacchiera, final Posizione attuale,
      final Posizione nuova) {

    boolean legale = false;
    int x = attuale.getRiga();
    int y = attuale.getColonna();
    int xNuova = nuova.getRiga();
    int yNuova = nuova.getColonna();

    if (this.getColore().equals("bianco")) {

      if (xNuova - x == 1 && Math.abs(yNuova - y) == 1) {

        if (primaMossa) {
          primaMossa = false;
        }
        legale = true;

      }
    } else {

      if (x - xNuova == 1 && Math.abs(yNuova - y) == 1) {

        if (primaMossa) {
          primaMossa = false;
        }
        legale = true;

      }
    }

    return legale;
  }

  /**
   * Restituisce se l'en passant e' legale o meno
   *
   * @param scacchiera Scacchiera della partita corrente
   * @param attuale Posizione attuale del pedone
   * @param nuova Posizione di cattura del pedone
   * @return true se l'en passant e' legale, false altrimenti
   * @author DarioSpinosa
   */
  public boolean enPassantLegale(final Scacchiera scacchiera, final Posizione attuale,
      final Posizione nuova) {

    boolean legale = false;
    int x = attuale.getRiga();
    int y = attuale.getColonna();
    int xNuova = nuova.getRiga();
    int yNuova = nuova.getColonna();

    if (this.getColore().equals("bianco")) {

      if (xNuova - x == 1 && Math.abs(yNuova - y) == 1) {

        if (scacchiera.getCasella(xNuova, yNuova).getVuota()
            && !(scacchiera.getCasella(xNuova - 1, yNuova).getVuota())
            && !(scacchiera.getCasella(xNuova - 1, yNuova).getPezzo().getColore())
                .equals(scacchiera.getCasella(x, y).getPezzo().getColore())) {

          if (GestoreMovimento.getInstance().getNumeroTurno()
              - 1 == ((Pedone) (scacchiera.getCasella(xNuova - 1, yNuova).getPezzo()))
                  .getPrimaMossaLunga()) {
            legale = true;
          }
        }
      }
    } else {

      if (x - xNuova == 1 && Math.abs(yNuova - y) == 1) {

        if (scacchiera.getCasella(xNuova, yNuova).getVuota()
            && !(scacchiera.getCasella(xNuova + 1, yNuova).getVuota())
            && !(scacchiera.getCasella(xNuova + 1, yNuova).getPezzo().getColore())
                .equals(scacchiera.getCasella(x, y).getPezzo().getColore())) {

          if (GestoreMovimento.getInstance().getNumeroTurno()
              - 1 == ((Pedone) (scacchiera.getCasella(xNuova + 1, yNuova).getPezzo()))
                  .getPrimaMossaLunga()) {
            legale = true;
          }
        }
      }
    }

    return legale;
  }
}
