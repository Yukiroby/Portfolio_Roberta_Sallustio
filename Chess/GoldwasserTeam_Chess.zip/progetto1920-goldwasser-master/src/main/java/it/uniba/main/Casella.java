package it.uniba.main;

/**
 * <Entity> Responsabilita': Rappresenta una casella, unita' elementare di una scacchiera. Conosce
 * il pezzo situato al suo interno.
 */
public class Casella {
  private Pezzo pezzo;
  private boolean vuota = true;

  /**
   * Costruttore per caselle non vuote, con un pezzo al loro interno
   *
   * @param parPezzo Pezzo degli scacchi che occupa la casella
   * @author yukiroby
   */
  public Casella(final Pezzo parPezzo) {
    this.pezzo = parPezzo;
    vuota = false;
  }

  public Casella() {

  }

  /**
   * @param parPezzo Pezzo con cui occupare la casella
   */
  public void setPezzo(final Pezzo parPezzo) {
    this.pezzo = parPezzo;
    vuota = false;
  }

  /**
   * @return pezzo Pezzo che occupa la casella
   */
  public Pezzo getPezzo() {
    return this.pezzo;
  }

  /**
   * @return true se la casella e' vuota, false altrimenti
   */
  public Boolean getVuota() {
    return this.vuota;
  }

  /**
   * @param parVuota true se la casella e' vuota, false altrimenti
   */
  public void setVuota(final Boolean parVuota) {
    this.vuota = parVuota;
  }

  /**
   *
   * @return simbolo notazione tipografica del pezzo o della casella (es. carattere Unicode,
   *         lettera...)
   */
  @Override
  public String toString() {
    if (vuota) {
      return "\u2002";
    }

    return pezzo.toString();
  }
}
