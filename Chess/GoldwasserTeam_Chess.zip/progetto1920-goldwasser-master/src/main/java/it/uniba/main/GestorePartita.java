package it.uniba.main;

/**
 * <Control> Responsabilita': Gestisce il flusso di una partita, con dei comandi ricevuti in input
 * dal giocatore. Conosce lo stato della partita corrente e permette di avviare, ricominciare e
 * chiudere una partita. Mette a disposizione un menu' di aiuto per il giocatore.
 */
public final class GestorePartita {
  private static GestorePartita gameHandler = new GestorePartita();
  private Partita partitaCorrente = new Partita();

  private GestorePartita() {

  }

  public static GestorePartita getInstance() {
    return gameHandler;
  }

  public Partita getPartita() {
    return partitaCorrente;
  }

  /**
   * Chiude il programma.
   * <p>
   * Chiede all'utente se vuole uscire dal gioco, controllando la correttezza della risposta
   *
   * @author FResta99
   */
  private void esci() {
    String risposta;
    do {
      System.out.println("Vuoi uscire? Rispondi 'si'/'no'");
      risposta = InputTastiera.getInstance().input();
      if (!(risposta.equalsIgnoreCase("si") || risposta.equalsIgnoreCase("no"))) {
        System.out.println("Risposta non accettata. Inserire 'si' o 'no'");
      }
    } while (!(risposta.equalsIgnoreCase("si") || risposta.equalsIgnoreCase("no")));

    if (risposta.equalsIgnoreCase("si")) {
      System.out.println("Chiusura in corso... Alla prossima!");
      InterfacciaUtente.getInstance().setEsci(true);
      partitaCorrente.invertiMossaFatta();
      partitaCorrente.setPartitaIniziata(false);
    }

  }

  /**
   * Fa ricominciare la partita
   * <p>
   * Chiede all'utente se vuole ricominciare la partita, controllando la correttezza della risposta
   *
   * @author matteomannavola
   */
  private void ricomincia() {
    String risposta;

    do {
      System.out.println(
          "E' gia' in corso una partita. Sicuro di voler ricominciare? Rispondi 'si'/'no'");
      risposta = InputTastiera.getInstance().input();
      if (!(risposta.equalsIgnoreCase("si") || risposta.equalsIgnoreCase("no"))) {
        System.out.println("Risposta non accettata. Inserire 'si' o 'no'");
      }
    } while (!(risposta.equalsIgnoreCase("si") || risposta.equalsIgnoreCase("no")));

    if (risposta.equalsIgnoreCase("si")) {
      System.out.println("Creazione di una nuova partita...");
      partitaCorrente.invertiMossaFatta();
      partitaCorrente.setPartitaIniziata(false);


    }

  }

  /**
   * Gestisce i comandi del gioco, invocando metodi di altre classi sulla base della stringa in
   * input ricevuta dal giocatore
   *
   * @param input stringa riconosciuta come sintatticamente corretta dall'Interfaccia Utente
   * @return eventoEffettuato "true" se e' stato effettuato un comando, "false" altrimenti
   */
  public boolean evento(final String input) {
    boolean eventoEffettuato = true;
    switch (input) {
      case "play":
        if (partitaCorrente.getPartitaIniziata()) {
          ricomincia();
        }

        if (!partitaCorrente.getPartitaIniziata()) {
          System.out.println("Partita iniziata! Inserisci una mossa o un comando");
          partitaCorrente.inizia();
        }

        break;

      case "board":
        if (partitaCorrente.getPartitaIniziata()) {
          InterfacciaUtente.getInstance().visualizzaScacchiera(partitaCorrente.getScacchiera());
        } else {
          InterfacciaUtente.getInstance().messaggioNessunaPartita();
        }
        break;

      case "captures":
        if (partitaCorrente.getPartitaIniziata()) {
          InterfacciaUtente.getInstance().stampaCatture(partitaCorrente);
        } else {
          InterfacciaUtente.getInstance().messaggioNessunaPartita();
        }
        break;

      case "moves":
        if (partitaCorrente.getPartitaIniziata()) {
          InterfacciaUtente.getInstance().stampaStorico(partitaCorrente);
        } else {
          InterfacciaUtente.getInstance().messaggioNessunaPartita();
        }
        break;

      case "quit":
        esci();
        break;

      case "help":
        InterfacciaUtente.getInstance().help();
        break;

      default:
        eventoEffettuato = false;
    }
    return eventoEffettuato;
  }
}
