package it.uniba.main;

/**
 * <NOECB> Responsabilita': classe principale del programma, stampa a video un messaggio di
 * benvenuto e richiama il metodo principale del programma
 */
public final class AppMain {

  /**
   * Private constructor. Change if needed.
   */
  private AppMain() {

  }

  /**
   * * This is the main entry of the application.
   *
   * @param args The command-line arguments.
   */
  public static void main(final String[] args) {
    InterfacciaUtente.getInstance().messaggioBenvenuto();
    while (!InterfacciaUtente.getInstance().getEsci()) {
      InterfacciaUtente.getInstance().input();
    }
    InputTastiera.getInstance().close();
}

}
