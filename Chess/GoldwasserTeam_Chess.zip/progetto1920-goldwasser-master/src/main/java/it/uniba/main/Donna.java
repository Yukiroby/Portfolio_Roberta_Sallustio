package it.uniba.main;

/**
 * <Entity> Responsabilita': Rappresenta il pezzo degli scacchi "Donna". Verifica la correttezza
 * delle mosse di cattura e movimento.
 */
public final class Donna extends Pezzo {
  private static final String BIANCO = "\u2655";
  private static final String NERO = "\u265B";

  /**
   * Crea un nuovo pezzo di tipo Donna
   *
   * @param colore "bianco" o "nero", case unsensitive
   * @author FResta99, paolodamianomanzoni
   */
  public Donna(final String colore) {
    if (colore.equalsIgnoreCase("bianco")) {
      setColore(colore);
      setSimbolo(BIANCO);
    } else if (colore.equalsIgnoreCase("nero")) {
      setColore(colore);
      setSimbolo(NERO);
    } else {
      setColore("bianco");
      setSimbolo(BIANCO);
    }
  }

  /**
   * Controlla se una mossa di movimento della donna e' legale o meno <br>
   * Richiama il metodo movimentoGenerico poiche' cattura e movimento della donna sono simili
   *
   * @param scacchiera Scacchiera della partita corrente
   * @param attuale Posizione attuale della donna
   * @param nuova Posizione di arrivo della donna
   * @return true se la mossa e' legale, false altrimenti
   * @author m-elio
   */
  @Override
  public boolean mossaLegale(final Scacchiera scacchiera, final Posizione attuale,
      final Posizione nuova) {
    return movimentoGenerico(scacchiera, attuale, nuova);
  }

  /**
   * Controlla se una cattura della donna e' legale o meno <br>
   * Richiama il metodo movimentoGenerico poiche' cattura e movimento della donna sono simili
   *
   * @param scacchiera Scacchiera della partita corrente
   * @param attuale Posizione attuale della donna
   * @param nuova Posizione di cattura della donna
   * @return true se la cattura e' legale, false altrimenti
   * @author m-elio
   */
  @Override
  public boolean catturaLegale(final Scacchiera scacchiera, final Posizione attuale,
      final Posizione nuova) {
    return movimentoGenerico(scacchiera, attuale, nuova);
  }

  /**
   * Controlla se un generica mossa della donna, cattura o movimento, sia legale o meno
   *
   * @param scacchiera Scacchiera della partita corrente
   * @param attuale Posizione attuale della donna
   * @param nuova Posizione di arrivo della donna
   * @return true se la mossa e' legale, false altrimenti
   * @author m-elio
   */
  private boolean movimentoGenerico(final Scacchiera scacchiera, final Posizione attuale,
      final Posizione nuova) {
    boolean legale = false;
    int x = attuale.getRiga();
    int y = attuale.getColonna();
    int xNuova = nuova.getRiga();
    int yNuova = nuova.getColonna();
    int differenzaX = xNuova - x;
    int differenzaY = yNuova - y;

    if (Math.abs(differenzaX) == Math.abs(differenzaY)) {
      boolean controllo = true;
      for (int i = 1; i < Math.abs(differenzaX); i++) {
        if (differenzaX < 0 && differenzaY < 0) {
          if (!scacchiera.getCasella(x - i, y - i).getVuota()) {
            controllo = false;
          }
        } else if (differenzaX < 0 && differenzaY > 0) {
          if (!scacchiera.getCasella(x - i, y + i).getVuota()) {
            controllo = false;
          }
        } else if (differenzaX > 0 && differenzaY < 0) {
          if (!scacchiera.getCasella(x + i, y - i).getVuota()) {
            controllo = false;
          }
        } else if (differenzaX > 0 && differenzaY > 0) {
          if (!scacchiera.getCasella(x + i, y + i).getVuota()) {
            controllo = false;
          }
        }
      }
      if (controllo) {
        legale = true;
      }

    } else if (Math.abs(differenzaX) > 0 && differenzaY == 0) {
      boolean controllo = true;
      for (int i = 1; i < Math.abs(differenzaX); i++) {
        if (differenzaX > 0) {
          if (!scacchiera.getCasella(x + i, y).getVuota()) {
            controllo = false;
          }
        } else {
          if (!scacchiera.getCasella(x - i, y).getVuota()) {
            controllo = false;
          }
        }
      }
      if (controllo) {
        legale = true;
      }

    } else if (differenzaX == 0 && Math.abs(differenzaY) > 0) {
      boolean controllo = true;
      for (int i = 1; i < Math.abs(differenzaY); i++) {
        if (differenzaY > 0) {
          if (!scacchiera.getCasella(x, y + i).getVuota()) {
            controllo = false;
          }
        } else {
          if (!scacchiera.getCasella(x, y - i).getVuota()) {
            controllo = false;
          }
        }
      }
      if (controllo) {
        legale = true;
      }
    }

    return legale;
  }
}
