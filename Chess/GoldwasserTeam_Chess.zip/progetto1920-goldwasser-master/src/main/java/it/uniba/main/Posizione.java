package it.uniba.main;

/**
 * <Entity> Responsabilita': Rappresenta una posizione in uno spazio bidimensionale.
 *
 */

public class Posizione {
  private int riga;
  private int colonna;

  /**
   * Crea una nuova posizione in uno spazio bidimensionale
   *
   * @param x coordinata X della posizione
   * @param y coordinata Y della posizione
   */
  public Posizione(final int x, final int y) {
    setRiga(x);
    setColonna(y);
  }

  /**
   * @param x coordinata X della posizione
   */
  public void setRiga(final int x) {
    riga = x;
  }

  /**
   * @param y coordinata Y della posizione
   */
  public void setColonna(final int y) {
    colonna = y;
  }

  /**
   * @return coordinata X della posizione
   */
  public int getRiga() {
    return riga;
  }

  /**
   * @return coordinata Y della posizione
   */
  public int getColonna() {
    return colonna;
  }

  /**
   * Genera un codice univoco per una posizione
   *
   * @return result codice univoco
   */
  @Override
  public int hashCode() {
    final int prime = 31;
    int result = 1;
    result = prime * result + colonna;
    result = prime * result + riga;
    return result;
  }

  /**
   * Confronta due posizioni
   *
   * @param pos posizione da confrontare
   * @return true se le posizioni sono uguali, false altrimenti
   */
  @Override
  public boolean equals(final Object pos) {
    if (this == pos) {
      return true;
    }
    if (pos == null) {
      return false;
    }
    if (getClass() != pos.getClass()) {
      return false;
    }
    Posizione other = (Posizione) pos;
    if (colonna != other.colonna) {
      return false;
    }
    if (riga != other.riga) {
      return false;
    }
    return true;
  }


}
