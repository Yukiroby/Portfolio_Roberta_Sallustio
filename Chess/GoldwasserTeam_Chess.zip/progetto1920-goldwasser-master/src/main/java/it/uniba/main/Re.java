package it.uniba.main;

/**
 * <Entity> Responsabilita': Rappresenta il pezzo degli scacchi "Re". Verifica la correttezza delle
 * mosse di cattura e movimento.
 */
public final class Re extends Pezzo {
  private static final String BIANCO = "\u2654";
  private static final String NERO = "\u265A";
  private boolean primaMossa = true;

  /**
   * Crea un nuovo pezzo di tipo Re
   *
   * @param colore "bianco" o "nero", case unsensitive
   * @author FResta99, paolodamianomanzoni
   */
  public Re(final String colore) {
    if (colore.equalsIgnoreCase("bianco")) {
      setColore(colore);
      setSimbolo(BIANCO);
    } else if (colore.equalsIgnoreCase("nero")) {
      setColore(colore);
      setSimbolo(NERO);
    } else {
      setColore("bianco");
      setSimbolo(BIANCO);
    }
  }

  /**
   * Stabilisce se il re ha effettuato la sua prima mossa. <br>
   * Viene utilizzato nel controllo per l'arrocco
   *
   * @return true se il re e' stato mosso, false altrimenti
   */
  public boolean getPrimaMossa() {
    return primaMossa;
  }

  public void invertiPrima() {
    primaMossa = !primaMossa;
  }

  /**
   * Controlla se una mossa del re e' legale o meno <br>
   * Richiama il metodo movimentoGenerico poiche' cattura e movimento del re sono simili
   *
   * @param scacchiera Scacchiera della partita corrente
   * @param attuale Posizione attuale del re
   * @param nuova Posizione di arrivo del re
   * @return true se la mossa e' legale, false altrimenti
   * @author DarioSpinosa
   */
  @Override
  public boolean mossaLegale(final Scacchiera scacchiera, final Posizione attuale,
      final Posizione nuova) {
    return movimentoGenerico(scacchiera, attuale, nuova);
  }

  /**
   * Controlla se una cattura del re e' legale o meno. <br>
   * Richiama il metodo movimentoGenerico poiche' cattura e movimento del re sono simili
   *
   * @param scacchiera Scacchiera della partita corrente
   * @param attuale Posizione attuale del re
   * @param nuova Posizione di cattura del re
   * @return true se la cattura e' legale, false altrimenti
   * @author DarioSpinosa
   */
  @Override
  public boolean catturaLegale(final Scacchiera scacchiera, final Posizione attuale,
      final Posizione nuova) {
    return movimentoGenerico(scacchiera, attuale, nuova);
  }

  /**
   * Controlla se un generica mossa del re, cattura o movimento, sia legale o meno
   *
   * @param scacchiera Scacchiera della partita corrente
   * @param attuale Posizione attuale del re
   * @param nuova Posizione di arrivo del re
   * @return true se la mossa e' legale, false altrimenti
   * @author DarioSpinosa
   */
  private boolean movimentoGenerico(final Scacchiera scacchiera, final Posizione attuale,
      final Posizione nuova) {
    boolean legale = false;
    int xNuova = nuova.getRiga();
    int yNuova = nuova.getColonna();
    int x = attuale.getRiga();
    int y = attuale.getColonna();

    if (((Math.abs(xNuova - x) == 1) || xNuova - x == 0)
        && ((Math.abs(yNuova - y) == 1) || yNuova - y == 0)) {

      if (primaMossa) {
        primaMossa = false;
      }
      legale = true;
    }

    return legale;
  }
}
