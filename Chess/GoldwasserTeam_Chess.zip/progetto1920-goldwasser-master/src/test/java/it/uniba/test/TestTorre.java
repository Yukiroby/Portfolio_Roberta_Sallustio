package it.uniba.test;

import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import it.uniba.main.Pedone;
import it.uniba.main.Posizione;
import it.uniba.main.Scacchiera;
import it.uniba.main.Torre;


class TestTorre {

  Torre temp;
  Scacchiera scacchiera;

  @BeforeEach
  void setUp() throws Exception {
    temp = new Torre("verde");
    scacchiera = new Scacchiera(true);
  }

  @AfterEach
  void tearDown() throws Exception {}

  @Test
  void testInvertiPrimaMossa() {
	  temp.invertiPrima();
	  temp.invertiPrima();
	  assertTrue(temp.getPrimaMossa());
  }

  @Test
  void testMossaLegale() {
    scacchiera.getCasella(2, 2).setPezzo(temp);
    temp = (Torre) (scacchiera.getCasella(2, 2).getPezzo());
    assertTrue(temp.mossaLegale(scacchiera, new Posizione(2, 2), new Posizione(2, 5)));
  }

  @Test
  void testMossaIllegale() {
    scacchiera.getCasella(2, 2).setPezzo(temp);
    temp = (Torre) (scacchiera.getCasella(2, 2).getPezzo());
    assertFalse(temp.mossaLegale(scacchiera, new Posizione(2, 2), new Posizione(5, 1)));
  }

  @Test
  void testCatturaLegale() {
    scacchiera.getCasella(2, 2).setPezzo(temp);
    scacchiera.getCasella(3, 2).setPezzo(new Pedone("bianco"));
    temp = (Torre) (scacchiera.getCasella(2, 2).getPezzo());
    assertTrue(temp.catturaLegale(scacchiera, new Posizione(2, 2), new Posizione(3, 2)));
  }

  @Test
  void testCatturaIllegale() {
    scacchiera.getCasella(7, 7).setPezzo(temp);
    scacchiera.getCasella(0, 1).setPezzo(new Pedone("bianco"));
    temp = (Torre) (scacchiera.getCasella(7, 7).getPezzo());
    assertFalse(temp.catturaLegale(scacchiera, new Posizione(7, 7), new Posizione(3, 3)));
  }

  @Test
  @SuppressWarnings("rawtypes")
  void testMovimentoGenericoLegale() throws NoSuchMethodException, IllegalAccessException,
      IllegalArgumentException, InvocationTargetException {
    Class[] parametri = new Class[3];
    parametri[0] = Scacchiera.class;
    parametri[1] = Posizione.class;
    parametri[2] = Posizione.class;
    Method movimento = temp.getClass().getDeclaredMethod("movimentoGenerico", parametri);
    movimento.setAccessible(true);
    Object[] argomenti = new Object[3];
    argomenti[0] = scacchiera;
    argomenti[1] = new Posizione(7, 7);
    argomenti[2] = new Posizione(5, 7);
    boolean returned = (boolean) movimento.invoke(temp, argomenti);
    assertTrue(returned);
  }

  @Test
  @SuppressWarnings("rawtypes")
  void testMovimentoGenericoLegaleAlto() throws NoSuchMethodException, IllegalAccessException,
      IllegalArgumentException, InvocationTargetException {
    Class[] parametri = new Class[3];
    parametri[0] = Scacchiera.class;
    parametri[1] = Posizione.class;
    parametri[2] = Posizione.class;
    Method movimento = temp.getClass().getDeclaredMethod("movimentoGenerico", parametri);
    movimento.setAccessible(true);
    Object[] argomenti = new Object[3];
    argomenti[0] = scacchiera;
    argomenti[1] = new Posizione(0, 0);
    argomenti[2] = new Posizione(2, 0);
    boolean returned = (boolean) movimento.invoke(temp, argomenti);
    assertTrue(returned);
  }

  @SuppressWarnings("rawtypes")
  @Test
  void testMovimentoGenericoIlLegaleAlto() throws NoSuchMethodException, IllegalAccessException,
  IllegalArgumentException, InvocationTargetException {
	  scacchiera = new Scacchiera(true);
	  scacchiera.getCasella(0, 0).setPezzo(new Torre("bianco"));
	  scacchiera.getCasella(1, 0).setPezzo(new Torre("bianco"));
	  Class[] parametri = new Class[3];
	  parametri[0] = Scacchiera.class;
	  parametri[1] = Posizione.class;
	  parametri[2] = Posizione.class;
	  Method movimento = temp.getClass().getDeclaredMethod("movimentoGenerico", parametri);
	  movimento.setAccessible(true);
	  Object[] argomenti = new Object[3];
	  argomenti[0] = scacchiera;
	  argomenti[1] = new Posizione(0, 0);
	  argomenti[2] = new Posizione(2, 0);
	  boolean returned = (boolean) movimento.invoke(temp, argomenti);
	  assertFalse(returned);
  }

  @SuppressWarnings("rawtypes")
  @Test
  void testMovimentoGenericoIlLegaleDestra() throws NoSuchMethodException, IllegalAccessException,
  IllegalArgumentException, InvocationTargetException {
	  scacchiera = new Scacchiera(true);
	  scacchiera.getCasella(0, 0).setPezzo(new Torre("bianco"));
	  scacchiera.getCasella(0, 1).setPezzo(new Torre("bianco"));
	  Class[] parametri = new Class[3];
	  parametri[0] = Scacchiera.class;
	  parametri[1] = Posizione.class;
	  parametri[2] = Posizione.class;
	  Method movimento = temp.getClass().getDeclaredMethod("movimentoGenerico", parametri);
	  movimento.setAccessible(true);
	  Object[] argomenti = new Object[3];
	  argomenti[0] = scacchiera;
	  argomenti[1] = new Posizione(0, 0);
	  argomenti[2] = new Posizione(0, 2);
	  boolean returned = (boolean) movimento.invoke(temp, argomenti);
	  assertFalse(returned);
  }

  @SuppressWarnings("rawtypes")
  @Test
  void testMovimentoGenericoIlLegaleSotto() throws NoSuchMethodException, IllegalAccessException,
  IllegalArgumentException, InvocationTargetException {
	  scacchiera = new Scacchiera(true);
	  scacchiera.getCasella(2, 0).setPezzo(new Torre("bianco"));
	  scacchiera.getCasella(1, 0).setPezzo(new Torre("bianco"));
	  Class[] parametri = new Class[3];
	  parametri[0] = Scacchiera.class;
	  parametri[1] = Posizione.class;
	  parametri[2] = Posizione.class;
	  Method movimento = temp.getClass().getDeclaredMethod("movimentoGenerico", parametri);
	  movimento.setAccessible(true);
	  Object[] argomenti = new Object[3];
	  argomenti[0] = scacchiera;
	  argomenti[1] = new Posizione(2, 0);
	  argomenti[2] = new Posizione(0, 0);
	  boolean returned = (boolean) movimento.invoke(temp, argomenti);
	  assertFalse(returned);
  }
  @Test
  @SuppressWarnings("rawtypes")
  void testMovimentoGenericoIllegale() throws NoSuchMethodException, IllegalAccessException,
      IllegalArgumentException, InvocationTargetException {
    Class[] parametri = new Class[3];
    parametri[0] = Scacchiera.class;
    parametri[1] = Posizione.class;
    parametri[2] = Posizione.class;
    Method movimento = temp.getClass().getDeclaredMethod("movimentoGenerico", parametri);
    movimento.setAccessible(true);
    Object[] argomenti = new Object[3];
    argomenti[0] = scacchiera;
    argomenti[1] = new Posizione(2, 4);
    argomenti[2] = new Posizione(1, 2);
    boolean returned = (boolean) movimento.invoke(temp, argomenti);
    assertFalse(returned);
  }

}
