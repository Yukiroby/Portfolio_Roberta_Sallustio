package it.uniba.test;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import it.uniba.main.Re;
import it.uniba.main.Pedone;
import it.uniba.main.Posizione;
import it.uniba.main.Scacchiera;

class TestRe{

  private Re temp;
  private Re temp2;
  private Re temp3;
  private Scacchiera scacchiera;

  @BeforeEach
  void setUp() throws Exception {
    temp = new Re("bianco");
    temp2 = new Re("nero");
    temp3 = new Re("verde");
    scacchiera = new Scacchiera(true);
	scacchiera.getCasella(2, 2).setPezzo(temp);
	scacchiera.getCasella(7, 3).setPezzo(temp2);
	scacchiera.getCasella(7, 6).setPezzo(temp3);
  }
  @Test 
  void testGetPrimaMossa() {
	  assertTrue(temp.getPrimaMossa());
  }

  @Test
  void testGetPrimaMossaFalsa() {
	  assertTrue(temp.mossaLegale(scacchiera, new Posizione(2, 2), new Posizione(3, 3)));
	  assertFalse(temp.getPrimaMossa());
  }
  
  @Test
  void testInvertiPrimaToFalse() {
	  temp.invertiPrima();
	  assertFalse(temp.getPrimaMossa());
  }
  
  @Test
  void testInvertiPrimaToTrue() {
	  temp.invertiPrima();
	  temp.invertiPrima();
	  assertTrue(temp.getPrimaMossa());
  }
  

  @Test
  void testMossaLegale() {
    assertTrue(temp.mossaLegale(scacchiera, new Posizione(2, 2), new Posizione(3, 2)));
  }

  @Test
  void testMossaIllegale() {
    assertFalse(temp2.mossaLegale(scacchiera, new Posizione(2, 2), new Posizione(2, 4)));
  }

  @Test
  void testCatturaLegale() {
    scacchiera.getCasella(3, 3).setPezzo(new Pedone("nero"));
    assertTrue(temp.catturaLegale(scacchiera, new Posizione(2, 2), new Posizione(3, 3)));
  }

  @Test
  void testCatturaIllegale() {
    scacchiera.getCasella(4, 2).setPezzo(new Pedone("nero"));
    assertFalse( temp3.catturaLegale(scacchiera, new Posizione(4, 2),
        new Posizione(Integer.MAX_VALUE, Integer.MIN_VALUE)));
  }
  
  @Test
  @SuppressWarnings("rawtypes")
  void testMovimentoGenerico() throws NoSuchMethodException, SecurityException, 
  IllegalAccessException, IllegalArgumentException, InvocationTargetException {
	    Class[] params = new Class[3];
	    params[0] = Scacchiera.class;
	    params[1] = Posizione.class;
	    params[2] = Posizione.class;
	    Method method = temp.getClass().getDeclaredMethod("movimentoGenerico", params);
	    Object[] valori = new Object[3];
	    valori[0] = scacchiera;
	    valori[1] = new Posizione(2 , 2);
	    valori[2] = new Posizione(3 , 3);
	    method.setAccessible(true);
	    boolean returned = (boolean) method.invoke(temp, valori);
	    assertTrue(returned);
  }
  
  @Test
  @SuppressWarnings("rawtypes")
  void testMovimentoGenericoIllegale() throws NoSuchMethodException, SecurityException, 
  IllegalAccessException, IllegalArgumentException, InvocationTargetException {
		Class[] params = new Class[3];
	    params[0] = Scacchiera.class;
	    params[1] = Posizione.class;
	    params[2] = Posizione.class;
	    Method method = temp.getClass().getDeclaredMethod("movimentoGenerico", params);
	    Object[] valori = new Object[3];
	    valori[0] = scacchiera;
	    valori[1] = new Posizione(2 , 2);
	    valori[2] = new Posizione(6 , 3);
	    method.setAccessible(true);
	    boolean returned = (boolean) method.invoke(temp, valori);
	    assertFalse(returned);
  }
}
