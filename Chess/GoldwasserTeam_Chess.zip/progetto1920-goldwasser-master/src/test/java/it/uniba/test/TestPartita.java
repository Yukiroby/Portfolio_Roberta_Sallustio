package it.uniba.test;

import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import org.junit.jupiter.api.Test;
import it.uniba.main.Partita;

class TestPartita {

  private Partita p = new Partita();

  @Test
  void testInvertiMossaFatta() {
    p.invertiMossaFatta();
    p.invertiMossaFatta();
    assertFalse(p.getMossaFatta());
  }

  @Test
  void testGetStorico() {
    assertNotNull(p.getStorico());
  }

  @Test
  void testGetCatture() {
    assertNotNull(p.getCatture());
  }
}
