package it.uniba.test;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import it.uniba.main.Alfiere;
import it.uniba.main.Pedone;
import it.uniba.main.Posizione;
import it.uniba.main.Scacchiera;

class TestAlfiere{

  private Alfiere temp;
  private Scacchiera scacchiera;

  @BeforeEach
  void setUp() throws Exception {
    temp = new Alfiere("verde");
    scacchiera = new Scacchiera(true);
  }

  @Test
  void testMossaLegale() {
    scacchiera.getCasella(2, 2).setPezzo(temp);
    assertTrue(temp.mossaLegale(scacchiera, new Posizione(2, 2), new Posizione(3, 3)));
  }

  @Test
  void testMossaIllegale() {
    scacchiera.getCasella(2, 2).setPezzo(temp);
    assertFalse(temp.mossaLegale(scacchiera, new Posizione(2, 2), new Posizione(1, 2)));
  }

  @Test
  void testCatturaLegale() {
    scacchiera.getCasella(2, 2).setPezzo(temp);
    scacchiera.getCasella(0, 0).setPezzo(new Pedone("nero"));
    assertTrue(temp.catturaLegale(scacchiera, new Posizione(2, 2), new Posizione(0, 0)));
  }

  @Test
  void testCatturaIllegale() {
    scacchiera.getCasella(2, 2).setPezzo(temp);
    scacchiera.getCasella(1, 3).setPezzo(new Pedone("bianco"));
    scacchiera.getCasella(0, 4).setPezzo(new Pedone("nero"));
    assertFalse( temp.catturaLegale(scacchiera, new Posizione(2, 2),
        new Posizione(0, 4)));
  }

  @Test
  @SuppressWarnings("rawtypes")
  void testMovimentoGenericoIllegale() throws NoSuchMethodException, SecurityException,
  IllegalAccessException, IllegalArgumentException, InvocationTargetException {
	    scacchiera.getCasella(2, 2).setPezzo(temp);
		Class[] params = new Class[3];
	    params[0] = Scacchiera.class;
	    params[1] = Posizione.class;
	    params[2] = Posizione.class;
	    Method method = temp.getClass().getDeclaredMethod("movimentoGenerico", params);
	    Object[] valori = new Object[3];
	    valori[0] = scacchiera;
	    valori[1] = new Posizione(2 , 2);
	    valori[2] = new Posizione(2 , 3);
	    method.setAccessible(true);
	    boolean returned = (boolean) method.invoke(temp, valori);
	    assertFalse(returned);
  }

  @Test
  @SuppressWarnings("rawtypes")
  void testMovimentoGenericoIllegaleAltoADestra() throws NoSuchMethodException, SecurityException,
  IllegalAccessException, IllegalArgumentException, InvocationTargetException {
	  	scacchiera = new Scacchiera(true);
	    scacchiera.getCasella(1, 1).setPezzo(temp);
	    scacchiera.getCasella(2, 2).setPezzo(new Pedone("bianco"));
	    Class[] params = new Class[3];
	    params[0] = Scacchiera.class;
	    params[1] = Posizione.class;
	    params[2] = Posizione.class;
	    Method method = temp.getClass().getDeclaredMethod("movimentoGenerico", params);
	    Object[] valori = new Object[3];
	    valori[0] = scacchiera;
	    valori[1] = new Posizione(1 , 1);
	    valori[2] = new Posizione(3 , 3);
	    method.setAccessible(true);
	    boolean returned = (boolean) method.invoke(temp, valori);
	    assertFalse(returned);
  }

  @Test
  @SuppressWarnings("rawtypes")
  void testMovimentoGenericoIllegaleBassoASinistra() throws NoSuchMethodException, SecurityException,
  IllegalAccessException, IllegalArgumentException, InvocationTargetException {
	  	scacchiera = new Scacchiera(true);
	    scacchiera.getCasella(4, 4).setPezzo(temp);
	    scacchiera.getCasella(2, 2).setPezzo(temp);
	    Class[] params = new Class[3];
	    params[0] = Scacchiera.class;
	    params[1] = Posizione.class;
	    params[2] = Posizione.class;
	    Method method = temp.getClass().getDeclaredMethod("movimentoGenerico", params);
	    Object[] valori = new Object[3];
	    valori[0] = scacchiera;
	    valori[1] = new Posizione(4 , 4);
	    valori[2] = new Posizione(1 , 1);
	    method.setAccessible(true);
	    boolean returned = (boolean) method.invoke(temp, valori);
	    assertFalse(returned);
  }

  @Test
  @SuppressWarnings("rawtypes")
  void testMovimentoGenericoAltoASinistra() throws NoSuchMethodException, SecurityException,
  IllegalAccessException, IllegalArgumentException, InvocationTargetException {
	  	scacchiera = new Scacchiera(true);
	    scacchiera.getCasella(4, 4).setPezzo(temp);
	    Class[] params = new Class[3];
	    params[0] = Scacchiera.class;
	    params[1] = Posizione.class;
	    params[2] = Posizione.class;
	    Method method = temp.getClass().getDeclaredMethod("movimentoGenerico", params);
	    Object[] valori = new Object[3];
	    valori[0] = scacchiera;
	    valori[1] = new Posizione(4 , 4);
	    valori[2] = new Posizione(5 , 3);
	    method.setAccessible(true);
	    boolean returned = (boolean) method.invoke(temp, valori);
	    assertTrue(returned);
  }

  @Test
  @SuppressWarnings("rawtypes")
  void testMovimentoGenericoIllegaleAltoASinistra() throws NoSuchMethodException, SecurityException,
  IllegalAccessException, IllegalArgumentException, InvocationTargetException {
	  	scacchiera = new Scacchiera(true);
	    scacchiera.getCasella(4, 4).setPezzo(temp);
	    scacchiera.getCasella(5, 3).setPezzo(temp);
	    Class[] params = new Class[3];
	    params[0] = Scacchiera.class;
	    params[1] = Posizione.class;
	    params[2] = Posizione.class;
	    Method method = temp.getClass().getDeclaredMethod("movimentoGenerico", params);
	    Object[] valori = new Object[3];
	    valori[0] = scacchiera;
	    valori[1] = new Posizione(4 , 4);
	    valori[2] = new Posizione(6 , 2);
	    method.setAccessible(true);
	    boolean returned = (boolean) method.invoke(temp, valori);
	    assertFalse(returned);
  }

  @Test
  @SuppressWarnings("rawtypes")
  void testMovimentoGenericoBassoADestra() throws NoSuchMethodException, SecurityException,
  IllegalAccessException, IllegalArgumentException, InvocationTargetException {
	  	scacchiera = new Scacchiera(true);
	    scacchiera.getCasella(4, 4).setPezzo(temp);;
	    Class[] params = new Class[3];
	    params[0] = Scacchiera.class;
	    params[1] = Posizione.class;
	    params[2] = Posizione.class;
	    Method method = temp.getClass().getDeclaredMethod("movimentoGenerico", params);
	    Object[] valori = new Object[3];
	    valori[0] = scacchiera;
	    valori[1] = new Posizione(4 , 4);
	    valori[2] = new Posizione(3 , 5);
	    method.setAccessible(true);
	    boolean returned = (boolean) method.invoke(temp, valori);
	    assertTrue(returned);
  }

}
