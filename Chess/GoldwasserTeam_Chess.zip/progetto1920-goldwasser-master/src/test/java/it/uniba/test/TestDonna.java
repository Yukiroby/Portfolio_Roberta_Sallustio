package it.uniba.test;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import it.uniba.main.Donna;
import it.uniba.main.Pedone;
import it.uniba.main.Posizione;
import it.uniba.main.Scacchiera;

class TestDonna {

  private Donna temp;
  private Scacchiera scacchiera;

  @BeforeEach
  void setUp() throws Exception {
    temp = new Donna("verde");
    scacchiera = new Scacchiera(true);
  }

  @Test
  void testMossaLegaleAlto() {
    scacchiera.getCasella(2, 2).setPezzo(temp);
    temp = (Donna) (scacchiera.getCasella(2, 2).getPezzo());
    assertTrue(temp.mossaLegale(scacchiera, new Posizione(2, 2), new Posizione(6, 2)));
  }

  @Test
  void testMossaOstacolataAlto() {
    scacchiera.getCasella(2, 2).setPezzo(temp);
    scacchiera.getCasella(3, 2).setPezzo(new Pedone("bianco"));
    temp = (Donna) (scacchiera.getCasella(2, 2).getPezzo());
    assertFalse(temp.mossaLegale(scacchiera, new Posizione(2, 2), new Posizione(6, 2)));
  }

  @Test
  void testMossaLegaleBasso() {
    scacchiera.getCasella(2, 2).setPezzo(temp);
    temp = (Donna) (scacchiera.getCasella(2, 2).getPezzo());
    assertTrue(temp.mossaLegale(scacchiera, new Posizione(2, 2), new Posizione(0, 2)));
  }

  @Test
  void testMossaOstacolataBasso() {
    scacchiera.getCasella(2, 2).setPezzo(temp);
    scacchiera.getCasella(1, 2).setPezzo(new Pedone("bianco"));
    temp = (Donna) (scacchiera.getCasella(2, 2).getPezzo());
    assertFalse(temp.mossaLegale(scacchiera, new Posizione(2, 2), new Posizione(0, 2)));
  }

  @Test
  void testMossaLegaleSinistra() {
    scacchiera.getCasella(2, 2).setPezzo(temp);
    temp = (Donna) (scacchiera.getCasella(2, 2).getPezzo());
    assertTrue(temp.mossaLegale(scacchiera, new Posizione(2, 2), new Posizione(2, 0)));
  }

  @Test
  void testMossaOstacolataSinistra() {
    scacchiera.getCasella(2, 2).setPezzo(temp);
    scacchiera.getCasella(2, 1).setPezzo(new Pedone("bianco"));
    temp = (Donna) (scacchiera.getCasella(2, 2).getPezzo());
    assertFalse(temp.mossaLegale(scacchiera, new Posizione(2, 2), new Posizione(2, 0)));
  }

  @Test
  void testMossaLegaleDestra() {
    scacchiera.getCasella(2, 2).setPezzo(temp);
    temp = (Donna) (scacchiera.getCasella(2, 2).getPezzo());
    assertTrue(temp.mossaLegale(scacchiera, new Posizione(2, 2), new Posizione(2, 6)));
  }

  @Test
  void testMossaOstacolataDestra() {
    scacchiera.getCasella(2, 2).setPezzo(temp);
    scacchiera.getCasella(2, 5).setPezzo(new Pedone("bianco"));
    temp = (Donna) (scacchiera.getCasella(2, 2).getPezzo());
    assertFalse(temp.mossaLegale(scacchiera, new Posizione(2, 2), new Posizione(2, 6)));
  }

  @Test
  void testMossaLegaleAltoADestra() {
    scacchiera.getCasella(2, 2).setPezzo(temp);
    temp = (Donna) (scacchiera.getCasella(2, 2).getPezzo());
    assertTrue(temp.mossaLegale(scacchiera, new Posizione(2, 2), new Posizione(5, 5)));
  }


  @Test
  void testMossaOstacolataAltoADestra() {
    scacchiera.getCasella(2, 2).setPezzo(temp);
    scacchiera.getCasella(3, 3).setPezzo(new Pedone("bianco"));
    temp = (Donna) (scacchiera.getCasella(2, 2).getPezzo());
    assertFalse(temp.mossaLegale(scacchiera, new Posizione(2, 2), new Posizione(4, 4)));
  }


  @Test
  void testMossaLegaleBassoADestra() {
    scacchiera.getCasella(2, 2).setPezzo(temp);
    temp = (Donna) (scacchiera.getCasella(2, 2).getPezzo());
    assertTrue(temp.mossaLegale(scacchiera, new Posizione(2, 2), new Posizione(4, 0)));
  }


  @Test
  void testMossaOstacolataBassoADestra() {
    scacchiera.getCasella(2, 2).setPezzo(temp);
    scacchiera.getCasella(3, 1).setPezzo(new Pedone("bianco"));
    temp = (Donna) (scacchiera.getCasella(2, 2).getPezzo());
    assertFalse(temp.mossaLegale(scacchiera, new Posizione(2, 2), new Posizione(4, 0)));
  }

  @Test
  void testMossaLegaleAltoASinistra() {
    scacchiera.getCasella(2, 2).setPezzo(temp);
    temp = (Donna) (scacchiera.getCasella(2, 2).getPezzo());
    assertTrue(temp.mossaLegale(scacchiera, new Posizione(2, 2), new Posizione(0, 4)));
  }

  @Test
  void testMossaOstacolataAltoASinistra() {
    scacchiera.getCasella(2, 2).setPezzo(temp);
    scacchiera.getCasella(1, 3).setPezzo(new Pedone("bianco"));
    temp = (Donna) (scacchiera.getCasella(2, 2).getPezzo());
    assertFalse(temp.mossaLegale(scacchiera, new Posizione(2, 2), new Posizione(0, 4)));
  }

  @Test
  void testMossaLegaleBassoASinistra() {
    scacchiera.getCasella(2, 2).setPezzo(temp);
    temp = (Donna) (scacchiera.getCasella(2, 2).getPezzo());
    assertTrue(temp.mossaLegale(scacchiera, new Posizione(2, 2), new Posizione(0, 0)));
  }

  @Test
  void testMossaOstacolataBassoASinistra() {
    scacchiera.getCasella(2, 2).setPezzo(temp);
    scacchiera.getCasella(1, 1).setPezzo(new Pedone("bianco"));
    temp = (Donna) (scacchiera.getCasella(2, 2).getPezzo());
    assertFalse(temp.mossaLegale(scacchiera, new Posizione(2, 2), new Posizione(0, 0)));
  }

  @Test
  void testMossaIllegale() {
    scacchiera.getCasella(2, 2).setPezzo(temp);
    temp = (Donna) (scacchiera.getCasella(2, 2).getPezzo());
    assertFalse(temp.mossaLegale(scacchiera, new Posizione(2, 2), new Posizione(5, 3)));
  }

  @Test
  void testCatturaLegale() {
    scacchiera.getCasella(2, 2).setPezzo(temp);
    scacchiera.getCasella(3, 3).setPezzo(new Pedone("nero"));
    temp = (Donna) (scacchiera.getCasella(2, 2).getPezzo());
    assertTrue(temp.catturaLegale(scacchiera, new Posizione(2, 2), new Posizione(3, 3)));
  }

  @Test
  void testCatturaIllegale() {
    scacchiera.getCasella(2, 2).setPezzo(temp);
    scacchiera.getCasella(5, 3).setPezzo(new Pedone("nero"));
    temp = (Donna) (scacchiera.getCasella(2, 2).getPezzo());
    assertFalse(temp.catturaLegale(scacchiera, new Posizione(2, 2), new Posizione(5, 3)));
  }

  @Test
  void testCatturaOstacolata() {
    scacchiera.getCasella(2, 2).setPezzo(temp);
    scacchiera.getCasella(4, 4).setPezzo(new Pedone("bianco"));
    scacchiera.getCasella(5, 5).setPezzo(new Pedone("nero"));
    temp = (Donna) (scacchiera.getCasella(2, 2).getPezzo());
    assertFalse(temp.catturaLegale(scacchiera, new Posizione(2, 2), new Posizione(5, 5)));
  }

  @Test
  @SuppressWarnings("rawtypes")
  void testMovimentoGenerico() throws NoSuchMethodException, IllegalAccessException,
      IllegalArgumentException, InvocationTargetException {
    scacchiera.getCasella(2, 2).setPezzo(temp);
    Class[] params = new Class[3];
    params[0] = Scacchiera.class;
    params[1] = Posizione.class;
    params[2] = Posizione.class;
    Method method = temp.getClass().getDeclaredMethod("movimentoGenerico", params);
    Object[] valori = new Object[3];
    valori[0] = scacchiera;
    valori[1] = new Posizione(2, 2);
    valori[2] = new Posizione(4, 4);
    method.setAccessible(true);
    boolean returned = (boolean) method.invoke(temp, valori);
    assertTrue(returned);
  }

  @Test
  @SuppressWarnings("rawtypes")
  void testMovimentoGenericoIllegale() throws NoSuchMethodException, IllegalAccessException,
      IllegalArgumentException, InvocationTargetException {
    scacchiera.getCasella(2, 2).setPezzo(temp);
    Class[] params = new Class[3];
    params[0] = Scacchiera.class;
    params[1] = Posizione.class;
    params[2] = Posizione.class;
    Method method = temp.getClass().getDeclaredMethod("movimentoGenerico", params);
    Object[] valori = new Object[3];
    valori[0] = scacchiera;
    valori[1] = new Posizione(2, 2);
    valori[2] = new Posizione(4, 5);
    method.setAccessible(true);
    boolean returned = (boolean) method.invoke(temp, valori);
    assertFalse(returned);
  }
}
