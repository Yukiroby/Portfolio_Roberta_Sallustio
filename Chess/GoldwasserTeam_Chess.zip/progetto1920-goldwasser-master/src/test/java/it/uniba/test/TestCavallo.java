package it.uniba.test;

import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import it.uniba.main.Cavallo;
import it.uniba.main.Pedone;
import it.uniba.main.Posizione;
import it.uniba.main.Scacchiera;

class TestCavallo {

  Cavallo temp;
  Scacchiera scacchiera;

  @BeforeEach
  void setUp() throws Exception {
    temp = new Cavallo("verde");
    scacchiera = new Scacchiera(true);
  }

  @Test
  void testMossaLegale() {
    scacchiera.getCasella(2, 2).setPezzo(temp);
    temp = (Cavallo) (scacchiera.getCasella(2, 2).getPezzo());
    assertTrue(temp.mossaLegale(scacchiera, new Posizione(2, 2), new Posizione(4, 3)));
  }

  @Test
  void testMossaIllegale() {
    scacchiera.getCasella(2, 2).setPezzo(temp);
    temp = (Cavallo) (scacchiera.getCasella(2, 2).getPezzo());
    assertFalse(temp.mossaLegale(scacchiera, new Posizione(2, 2), new Posizione(5, 1)));
  }

  @Test
  void testCatturaLegale() {
    scacchiera.getCasella(2, 2).setPezzo(temp);
    scacchiera.getCasella(0, 1).setPezzo(new Pedone("bianco"));
    temp = (Cavallo) (scacchiera.getCasella(2, 2).getPezzo());
    assertTrue(temp.catturaLegale(scacchiera, new Posizione(2, 2), new Posizione(0, 1)));
  }

  @Test
  void testCatturaIllegale() {
    scacchiera.getCasella(7, 7).setPezzo(temp);
    scacchiera.getCasella(0, 1).setPezzo(new Pedone("bianco"));
    temp = (Cavallo) (scacchiera.getCasella(7, 7).getPezzo());
    assertFalse(temp.catturaLegale(scacchiera, new Posizione(5, 5), new Posizione(3, 3)));
  }

  @Test
  @SuppressWarnings("rawtypes")
  void testMovimentoGenericoLegale() throws NoSuchMethodException, IllegalAccessException,
      IllegalArgumentException, InvocationTargetException {
    Class[] parametri = new Class[3];
    parametri[0] = Scacchiera.class;
    parametri[1] = Posizione.class;
    parametri[2] = Posizione.class;
    Method movimento = temp.getClass().getDeclaredMethod("movimentoGenerico", parametri);
    movimento.setAccessible(true);
    Object[] argomenti = new Object[3];
    argomenti[0] = scacchiera;
    argomenti[1] = new Posizione(4, 5);
    argomenti[2] = new Posizione(5, 7);
    boolean returned = (boolean) movimento.invoke(temp, argomenti);
    assertTrue(returned);
  }

  @Test
  @SuppressWarnings("rawtypes")
  void testMovimentoGenericoIllegale() throws NoSuchMethodException, IllegalAccessException,
      IllegalArgumentException, InvocationTargetException {
    Class[] parametri = new Class[3];
    parametri[0] = Scacchiera.class;
    parametri[1] = Posizione.class;
    parametri[2] = Posizione.class;
    Method movimento = temp.getClass().getDeclaredMethod("movimentoGenerico", parametri);
    movimento.setAccessible(true);
    Object[] argomenti = new Object[3];
    argomenti[0] = scacchiera;
    argomenti[1] = new Posizione(2, 4);
    argomenti[2] = new Posizione(2, 2);
    boolean returned = (boolean) movimento.invoke(temp, argomenti);
    assertFalse(returned);
  }

}
