package it.uniba.test;

import static org.junit.Assert.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import it.uniba.main.Casella;
import it.uniba.main.Pedone;

class TestCasella {

	private Casella c;

	@BeforeEach
	void setUp() throws Exception {
		c = new Casella();
	}

	@Test
	void testSetPezzoDiverso() {
		c.setPezzo(new Pedone("bianco"));
		assertFalse(c.toString().contains("\u2657"));
	}

	@Test
	void testGetPezzo() {
		c.setPezzo(new Pedone("bianco"));
		assertTrue(c.getPezzo().getClass().toString().contains("Pedone"));
	}

	@Test
	void testGetVuota() {
		assertTrue(c.getVuota());
	}

	@Test
	void testCasellaPiena() {
		c.setPezzo(new Pedone("bianco"));
		assertFalse(c.getVuota());
	}

	@Test
	void testSetVuota() {
		c.setPezzo(new Pedone("bianco"));
		c.setVuota(true);
		assertTrue(c.getVuota());
	}

	@Test
	void testToStringCasellaVuota() {
		assertEquals("\u2002", c.toString());
	}

	@Test
    void testCostruttore() {
        c = new Casella(new Pedone("bianco"));
        assertFalse(c.toString().contains("\u2657"));
    }
}
