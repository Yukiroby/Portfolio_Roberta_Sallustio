
package it.uniba.test;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.ArrayList;

import org.junit.FixMethodOrder;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.runners.MethodSorters;

import it.uniba.main.Alfiere;
import it.uniba.main.Cavallo;
import it.uniba.main.Donna;
import it.uniba.main.GestoreMovimento;
import it.uniba.main.InterfacciaUtente;
import it.uniba.main.Partita;
import it.uniba.main.Pedone;
import it.uniba.main.Pezzo;
import it.uniba.main.Posizione;
import it.uniba.main.Re;
import it.uniba.main.Scacchiera;
import it.uniba.main.Torre;

// Running test cases in order of method names in ascending order
@FixMethodOrder(MethodSorters.NAME_ASCENDING)
class TestGestoreMovimento {

  private InterfacciaUtente i = InterfacciaUtente.getInstance();
  private GestoreMovimento test;
  private Field partitaField;
  private Partita partita;


  @BeforeEach
  void setUp() throws Exception {
    test = GestoreMovimento.getInstance();
    partitaField = test.getClass().getDeclaredField("partitaCorrente");
    partitaField.setAccessible(true);
    partitaField.set(test, new Partita());
    partita = (Partita) partitaField.get(test);
    partita.setPartitaIniziata(true);
  }


  @AfterEach
  void tearDown() throws Exception {}

  @Test
  void testGetNumeroTurno() {
    assertEquals(partita.getTurno(), 0);
  }

  @Test
  void testGetScacchiera() {
    assertNotEquals(partita.getScacchiera(), null);
  }

  @Test
  void testAzionePedoneBianco() throws NoSuchFieldException, SecurityException, IllegalArgumentException,
      IllegalAccessException {
    Scacchiera s = new Scacchiera(true);
    s.getCasella(0, 0).setPezzo(new Pedone("bianco"));
    Field scacc = partita.getClass().getDeclaredField("scacchiera");
    scacc.setAccessible(true);
    scacc.set(partita, s);
    assertTrue(test.azione("a3"));
  }

  @Test
  void testAzioneReBianco() throws NoSuchFieldException, SecurityException, IllegalArgumentException,
      IllegalAccessException {
    Scacchiera s = new Scacchiera(true);
    s.getCasella(0, 0).setPezzo(new Re("bianco"));
    Field scacc = partita.getClass().getDeclaredField("scacchiera");
    scacc.setAccessible(true);
    scacc.set(partita, s);
    assertTrue(test.azione("Ra2"));
  }

  @Test
  void testAzioneAlfiereBianco() throws NoSuchFieldException, SecurityException, IllegalArgumentException,
      IllegalAccessException {
    Scacchiera s = new Scacchiera(true);
    s.getCasella(0, 0).setPezzo(new Alfiere("bianco"));
    Field scacc = partita.getClass().getDeclaredField("scacchiera");
    scacc.setAccessible(true);
    scacc.set(partita, s);
    assertTrue(test.azione("Ac3"));
  }

  @Test
  void testAzioneDonnaBianca() throws NoSuchFieldException, SecurityException, IllegalArgumentException,
      IllegalAccessException {
    Scacchiera s = new Scacchiera(true);
    s.getCasella(0, 0).setPezzo(new Donna("bianco"));
    Field scacc = partita.getClass().getDeclaredField("scacchiera");
    scacc.setAccessible(true);
    scacc.set(partita, s);
    assertTrue(test.azione("Dc3"));
  }

  @Test
  void testAzioneTorreBianca() throws NoSuchFieldException, SecurityException, IllegalArgumentException,
      IllegalAccessException {
    Scacchiera s = new Scacchiera(true);
    s.getCasella(0, 0).setPezzo(new Torre("bianco"));
    Field scacc = partita.getClass().getDeclaredField("scacchiera");
    scacc.setAccessible(true);
    scacc.set(partita, s);
    assertTrue(test.azione("Ta8"));
  }

  @Test
  void testAzioneAlfiereNero() throws NoSuchFieldException, SecurityException, IllegalArgumentException,
      IllegalAccessException {
    Scacchiera s = new Scacchiera(true);
    s.getCasella(0, 0).setPezzo(new Alfiere("nero"));
    Field turno = partita.getClass().getDeclaredField("turnoBianco");
    turno.setAccessible(true);
    turno.set(partita, false);
    Field scacc = partita.getClass().getDeclaredField("scacchiera");
    scacc.setAccessible(true);
    scacc.set(partita, s);
    assertTrue(test.azione("Ac3"));
  }

  @Test
  void testAzioneCavalloNero() throws NoSuchFieldException, SecurityException, IllegalArgumentException,
      IllegalAccessException {
    Scacchiera s = new Scacchiera(true);
    s.getCasella(0, 0).setPezzo(new Cavallo("nero"));
    Field turno = partita.getClass().getDeclaredField("turnoBianco");
    turno.setAccessible(true);
    turno.set(partita, false);
    Field scacc = partita.getClass().getDeclaredField("scacchiera");
    scacc.setAccessible(true);
    scacc.set(partita, s);
    assertTrue(test.azione("Cc2"));
  }

  @Test
  void testAzioneDonnaNera() throws NoSuchFieldException, SecurityException, IllegalArgumentException,
      IllegalAccessException {
    Scacchiera s = new Scacchiera(true);
    s.getCasella(0, 0).setPezzo(new Donna("nero"));
    Field turno = partita.getClass().getDeclaredField("turnoBianco");
    turno.setAccessible(true);
    turno.set(partita, false);
    Field scacc = partita.getClass().getDeclaredField("scacchiera");
    scacc.setAccessible(true);
    scacc.set(partita, s);
    assertTrue(test.azione("Da8"));
  }

  @Test
  void testAzioneReNero() throws NoSuchFieldException, SecurityException, IllegalArgumentException,
      IllegalAccessException {
    Scacchiera s = new Scacchiera(true);
    s.getCasella(0, 0).setPezzo(new Re("nero"));
    Field turno = partita.getClass().getDeclaredField("turnoBianco");
    turno.setAccessible(true);
    turno.set(partita, false);
    Field scacc = partita.getClass().getDeclaredField("scacchiera");
    scacc.setAccessible(true);
    scacc.set(partita, s);
    assertTrue(test.azione("Ra2"));
  }

  @Test
  void testAzioneTorreNera() throws NoSuchFieldException, SecurityException, IllegalArgumentException,
      IllegalAccessException {
    Scacchiera s = new Scacchiera(true);
    s.getCasella(0, 0).setPezzo(new Torre("nero"));
    Field turno = partita.getClass().getDeclaredField("turnoBianco");
    turno.setAccessible(true);
    turno.set(partita, false);
    Field scacc = partita.getClass().getDeclaredField("scacchiera");
    scacc.setAccessible(true);
    scacc.set(partita, s);
    assertTrue(test.azione("Ta8"));
  }

  @Test
  void testAzioneIllegale() throws NoSuchFieldException, SecurityException, IllegalArgumentException,
      IllegalAccessException {
    Scacchiera s = new Scacchiera(true);
    s.getCasella(0, 0).setPezzo(new Pedone("bianco"));
    Field scacc = partita.getClass().getDeclaredField("scacchiera");
    scacc.setAccessible(true);
    scacc.set(partita, s);
    assertFalse(test.azione("a4"));
  }

  @Test
  void testMossaNonRiconosciuta() throws NoSuchFieldException, SecurityException, IllegalArgumentException,
      IllegalAccessException {
    assertFalse(test.azione("as2"));
  }


  @Test
  void testDisambiguazioneNonValidaMossaPerRiga() throws NoSuchFieldException, SecurityException, IllegalArgumentException,
      IllegalAccessException {
    Scacchiera s = new Scacchiera(true);
    s.getCasella(0, 0).setPezzo(new Torre("bianco"));
    s.getCasella(0, 4).setPezzo(new Torre("bianco"));
    Field scacc = partita.getClass().getDeclaredField("scacchiera");
    scacc.setAccessible(true);
    scacc.set(partita, s);
    assertFalse(test.azione("T1c1"));
  }

  @Test
  void testDisambiguazioneNonValidaMossaPerColonna() throws NoSuchFieldException, SecurityException, IllegalArgumentException,
      IllegalAccessException {
    Scacchiera s = new Scacchiera(true);
    s.getCasella(0, 0).setPezzo(new Torre("bianco"));
    s.getCasella(4, 0).setPezzo(new Torre("bianco"));
    Field scacc = partita.getClass().getDeclaredField("scacchiera");
    scacc.setAccessible(true);
    scacc.set(partita, s);
    assertFalse(test.azione("Taa3"));
  }

  @Test
  void testDisambiguazioneValidaMossaPerRiga() throws NoSuchFieldException, SecurityException, IllegalArgumentException,
      IllegalAccessException {
    Scacchiera s = new Scacchiera(true);
    s.getCasella(0, 0).setPezzo(new Torre("bianco"));
    s.getCasella(4, 0).setPezzo(new Torre("bianco"));
    Field scacc = partita.getClass().getDeclaredField("scacchiera");
    scacc.setAccessible(true);
    scacc.set(partita, s);
    assertTrue(test.azione("T1a3"));
  }

  @Test
  void testDisambiguazioneNonValidaCatturaPerColonna() throws NoSuchFieldException, SecurityException, IllegalArgumentException,
      IllegalAccessException {
    Scacchiera s = new Scacchiera(true);
    s.getCasella(0, 0).setPezzo(new Torre("bianco"));
    s.getCasella(4, 0).setPezzo(new Torre("bianco"));
    s.getCasella(2, 0).setPezzo(new Re("nero"));
    Field scacc = partita.getClass().getDeclaredField("scacchiera");
    scacc.setAccessible(true);
    scacc.set(partita, s);
    assertFalse(test.azione("Taxa3"));
  }

  @Test
  void testDisambiguazioneNecessaria() throws NoSuchFieldException, SecurityException, IllegalArgumentException,
      IllegalAccessException {
    Scacchiera s = new Scacchiera(true);
    s.getCasella(0, 0).setPezzo(new Torre("bianco"));
    s.getCasella(4, 0).setPezzo(new Torre("bianco"));
    Field scacc = partita.getClass().getDeclaredField("scacchiera");
    scacc.setAccessible(true);
    scacc.set(partita, s);
    assertFalse(test.azione("Ta3"));
  }

  @Test
  void testMuovi() throws NoSuchMethodException, SecurityException, IllegalAccessException,
      IllegalArgumentException, InvocationTargetException, NoSuchFieldException {
    Scacchiera s = new Scacchiera(true);
    s.getCasella(4, 3).setPezzo(new Pedone("nero"));
    Field scacc = partita.getClass().getDeclaredField("scacchiera");
    scacc.setAccessible(true);
    scacc.set(partita, s);
    Method temp = test.getClass().getDeclaredMethod("muovi", Scacchiera.class, int.class,
        Pezzo.class, Posizione.class, int.class);
    temp.setAccessible(true);
    temp.invoke(test, s, 0, new Pedone("nero"), new Posizione(3, 3), -1);
    assertTrue(s.getCasella(4, 3).getVuota());
  }

  @Test
  void testMuoviFallito() throws NoSuchMethodException, SecurityException, IllegalAccessException,
      IllegalArgumentException, InvocationTargetException, NoSuchFieldException {
    Scacchiera s = new Scacchiera(true);
    s.getCasella(4, 3).setPezzo(new Pedone("nero"));
    s.getCasella(3 ,3).setPezzo(new Pedone("nero"));
    Field scacc = partita.getClass().getDeclaredField("scacchiera");
    scacc.setAccessible(true);
    scacc.set(partita, s);
    Method temp = test.getClass().getDeclaredMethod("muovi", Scacchiera.class, int.class,
        Pezzo.class, Posizione.class, int.class);
    temp.setAccessible(true);
    temp.invoke(test, s, 0, new Pedone("nero"), new Posizione(3, 3), -1);
    assertFalse(s.getCasella(4, 3).getVuota());
  }

  @Test
  void testMuoviReSottoScacco() throws NoSuchMethodException, SecurityException, IllegalAccessException,
      IllegalArgumentException, InvocationTargetException, NoSuchFieldException {
    Scacchiera s = new Scacchiera(true);
    s.getCasella(0, 0).setPezzo(new Re("nero"));
    s.getCasella(1, 1).setPezzo(new Torre("bianco"));
    Field scacc = partita.getClass().getDeclaredField("scacchiera");
    scacc.setAccessible(true);
    scacc.set(partita, s);
    Method temp = test.getClass().getDeclaredMethod("muovi", Scacchiera.class, int.class,
        Pezzo.class, Posizione.class, int.class);
    temp.setAccessible(true);
    temp.invoke(test, s, 0, new Re("nero"), new Posizione(0, 1), -1);
    assertTrue(s.getCasella(0, 0).getPezzo() instanceof Re);
  }

  @Test
  void testMuoviReMinacciato() throws NoSuchMethodException, SecurityException, IllegalAccessException,
      IllegalArgumentException, InvocationTargetException, NoSuchFieldException {
    Scacchiera s = new Scacchiera(true);
    s.getCasella(0, 0).setPezzo(new Re("bianco"));
    s.getCasella(1, 1).setPezzo(new Pedone("bianco"));
    s.getCasella(2, 2).setPezzo(new Alfiere("nero"));
    Field scacc = partita.getClass().getDeclaredField("scacchiera");
    scacc.setAccessible(true);
    scacc.set(partita, s);
    Method temp = test.getClass().getDeclaredMethod("muovi", Scacchiera.class, int.class,
        Pezzo.class, Posizione.class, int.class);
    temp.setAccessible(true);
    temp.invoke(test, s, 0, new Pedone("bianco"), new Posizione(2, 1), -1);
    assertTrue(s.getCasella(1, 1).getPezzo() instanceof Pedone);
  }


  @Test
  void testCatturaFallito() throws NoSuchMethodException, SecurityException, IllegalAccessException,
      IllegalArgumentException, InvocationTargetException, NoSuchFieldException {
    Scacchiera s = new Scacchiera(true);
    s.getCasella(4, 3).setPezzo(new Pedone("nero"));
    s.getCasella(3, 3).setPezzo(new Pedone("bianco"));
    Field scacc = partita.getClass().getDeclaredField("scacchiera");
    scacc.setAccessible(true);
    scacc.set(partita, s);
    Method temp = test.getClass().getDeclaredMethod("cattura", Scacchiera.class, int.class,
        Pezzo.class, Posizione.class, int.class);
    temp.setAccessible(true);
    temp.invoke(test, s, 4, new Pedone("nero"), new Posizione(3, 3), 1);
    assertFalse(s.getCasella(4, 3).getVuota());
  }

  @Test
  void testCattura() throws NoSuchMethodException, SecurityException, IllegalAccessException,
      IllegalArgumentException, InvocationTargetException, NoSuchFieldException {
    Scacchiera s = new Scacchiera(true);
    s.getCasella(0, 0).setPezzo(new Pedone("bianco"));
    s.getCasella(1, 1).setPezzo(new Pedone("nero"));
    Field scacc = partita.getClass().getDeclaredField("scacchiera");
    scacc.setAccessible(true);
    scacc.set(partita, s);
    Method temp = test.getClass().getDeclaredMethod("cattura", Scacchiera.class, int.class,
        Pezzo.class, Posizione.class, int.class);
    temp.setAccessible(true);
    temp.invoke(test, s, 0, new Pedone("bianco"), new Posizione(1, 1), 1);
    assertTrue(s.getCasella(0, 0).getVuota());
  }

  @Test
  void testCatturaReSottoScacco() throws NoSuchMethodException, SecurityException, IllegalAccessException,
      IllegalArgumentException, InvocationTargetException, NoSuchFieldException {
    Scacchiera s = new Scacchiera(true);
    s.getCasella(0, 0).setPezzo(new Re("nero"));
    s.getCasella(1, 1).setPezzo(new Cavallo("bianco"));
    s.getCasella(2, 2).setPezzo(new Alfiere("bianco"));
    Field scacc = partita.getClass().getDeclaredField("scacchiera");
    scacc.setAccessible(true);
    scacc.set(partita, s);
    Method temp = test.getClass().getDeclaredMethod("cattura", Scacchiera.class, int.class,
        Pezzo.class, Posizione.class, int.class);
    temp.setAccessible(true);
    temp.invoke(test, s, 0, new Re("nero"), new Posizione(1, 1), -1);
    assertTrue(s.getCasella(1, 1).getPezzo() instanceof Cavallo);
  }

  @Test
  void testCatturaReMinacciato() throws NoSuchMethodException, SecurityException, IllegalAccessException,
      IllegalArgumentException, InvocationTargetException, NoSuchFieldException {
    Scacchiera s = new Scacchiera(true);
    s.getCasella(0, 0).setPezzo(new Re("bianco"));
    s.getCasella(1, 1).setPezzo(new Pedone("bianco"));
    s.getCasella(2, 0).setPezzo(new Pedone("nero"));
    s.getCasella(2, 2).setPezzo(new Alfiere("nero"));
    Field scacc = partita.getClass().getDeclaredField("scacchiera");
    scacc.setAccessible(true);
    scacc.set(partita, s);
    Method temp = test.getClass().getDeclaredMethod("cattura", Scacchiera.class, int.class,
    Pezzo.class, Posizione.class, int.class);
    temp.setAccessible(true);
    temp.invoke(test, s, 1, new Pedone("bianco"), new Posizione(2, 0), 1);
    assertTrue(s.getCasella(1, 1).getPezzo() instanceof Pedone);
  }

  @Test
  void testEnPassantBianco() throws NoSuchMethodException, SecurityException, IllegalAccessException,
      IllegalArgumentException, InvocationTargetException, NoSuchFieldException {
    Scacchiera s = new Scacchiera(true);
    s.getCasella(2, 2).setPezzo(new Pedone("bianco"));
    s.getCasella(2, 3).setPezzo(new Pedone("nero"));
    Field lunga =  s.getCasella(2, 3).getPezzo().getClass().getDeclaredField("primaMossaLunga");
    lunga.setAccessible(true);
    lunga.setInt(s.getCasella(2, 3).getPezzo(), -1);
    Field scacc = partita.getClass().getDeclaredField("scacchiera");
    scacc.setAccessible(true);
    scacc.set(partita, s);
    Method temp = test.getClass().getDeclaredMethod("cattura", Scacchiera.class, int.class,
    Pezzo.class, Posizione.class, int.class);
    temp.setAccessible(true);
    temp.invoke(test, s, 2, new Pedone("bianco"), new Posizione(3, 3), 1);
    assertTrue(s.getCasella(3, 3).getPezzo() instanceof Pedone);
  }

  @Test
  void testEnPassantIllegaleReMinacciato() throws NoSuchMethodException, SecurityException, IllegalAccessException,
      IllegalArgumentException, InvocationTargetException, NoSuchFieldException {
    Scacchiera s = new Scacchiera(true);
    s.getCasella(2, 2).setPezzo(new Pedone("bianco"));
    s.getCasella(2, 3).setPezzo(new Pedone("nero"));
    s.getCasella(3, 1).setPezzo(new Re("bianco"));
    s.getCasella(1, 3).setPezzo(new Alfiere("nero"));
    Field lunga =  s.getCasella(2, 3).getPezzo().getClass().getDeclaredField("primaMossaLunga");
    lunga.setAccessible(true);
    lunga.setInt(s.getCasella(2, 3).getPezzo(), -1);
    Field scacc = partita.getClass().getDeclaredField("scacchiera");
    scacc.setAccessible(true);
    scacc.set(partita, s);
    Method temp = test.getClass().getDeclaredMethod("cattura", Scacchiera.class, int.class,
    Pezzo.class, Posizione.class, int.class);
    temp.setAccessible(true);
    temp.invoke(test, s, 2, new Pedone("bianco"), new Posizione(3, 3), 1);
    assertTrue(s.getCasella(2, 2).getPezzo() instanceof Pedone);
  }

  @Test
  void testEnPassantNero() throws NoSuchMethodException, SecurityException, IllegalAccessException,
      IllegalArgumentException, InvocationTargetException, NoSuchFieldException {
	  Scacchiera s = new Scacchiera(true);
	    s.getCasella(4, 4).setPezzo(new Pedone("nero"));
	    s.getCasella(4, 3).setPezzo(new Pedone("bianco"));
	    Field turno = partita.getClass().getDeclaredField("turnoBianco");
	    turno.setAccessible(true);
	    turno.set(partita, false);
	    Field lunga =  s.getCasella(4, 3).getPezzo().getClass().getDeclaredField("primaMossaLunga");
	    lunga.setAccessible(true);
	    lunga.setInt(s.getCasella(4, 3).getPezzo(), -1);
	    Field scacc = partita.getClass().getDeclaredField("scacchiera");
	    scacc.setAccessible(true);
	    scacc.set(partita, s);
	    Method temp = test.getClass().getDeclaredMethod("cattura", Scacchiera.class, int.class,
	    Pezzo.class, Posizione.class, int.class);
	    temp.setAccessible(true);
	    temp.invoke(test, s, 4, new Pedone("nero"), new Posizione(3, 3), 1);
	    partita.setCatture(new Pedone("nero"));
	    partita.setMosse("dxc3");
	    partita.setMosse("c2");
	    partita.setMosse("c1");
	    i.stampaCatture(partita);
	    i.stampaStorico(partita);
	    i.visualizzaScacchiera(s);
	    assertTrue(s.getCasella(3, 3).getPezzo() instanceof Pedone);
  }

  @SuppressWarnings("unchecked")
  @Test
  void testTrovaPezzi() throws NoSuchMethodException, SecurityException, NoSuchFieldException,
      IllegalArgumentException, IllegalAccessException, InvocationTargetException {
    Scacchiera s = new Scacchiera(true);
    s.getCasella(0, 0).setPezzo(new Pedone("bianco"));
    Field scacc = partita.getClass().getDeclaredField("scacchiera");
    scacc.setAccessible(true);
    scacc.set(partita, s);
    Method temp = test.getClass().getDeclaredMethod("trovaPezzi", Pezzo.class);
    temp.setAccessible(true);
    ArrayList<Posizione> lista = (ArrayList<Posizione>) temp.invoke(test, new Pedone("bianco"));
    assertTrue(lista.size() == 1);
  }

  @SuppressWarnings("unchecked")
  @Test
  void testTrovaPezziFallito()
      throws NoSuchMethodException, SecurityException, NoSuchFieldException,
      IllegalArgumentException, IllegalAccessException, InvocationTargetException {
    Scacchiera s = new Scacchiera(true);
    Field scacc = partita.getClass().getDeclaredField("scacchiera");
    scacc.setAccessible(true);
    scacc.set(partita, s);
    Method temp = test.getClass().getDeclaredMethod("trovaPezzi", Pezzo.class);
    temp.setAccessible(true);
    ArrayList<Posizione> lista = (ArrayList<Posizione>) temp.invoke(test, new Pedone("bianco"));
    assertTrue(lista.size() == 0);
  }

  @SuppressWarnings("unchecked")
  @Test
  void testTrovaPezziCoordinata()
      throws NoSuchMethodException, SecurityException, NoSuchFieldException,
      IllegalArgumentException, IllegalAccessException, InvocationTargetException {
    Scacchiera s = new Scacchiera(true);
    s.getCasella(0, 0).setPezzo(new Torre("bianco"));
    Field scacc = partita.getClass().getDeclaredField("scacchiera");
    scacc.setAccessible(true);
    scacc.set(partita, s);
    Method temp =
        test.getClass().getDeclaredMethod("trovaPezzi", int.class, Pezzo.class, int.class);
    temp.setAccessible(true);
    ArrayList<Posizione> lista =
        (ArrayList<Posizione>) temp.invoke(test, 0, new Torre("bianco"), 1);
    assertTrue(lista.size() == 1);
  }

  @SuppressWarnings("unchecked")
  @Test
  void testTrovaPezziCoordinataFallito()
      throws NoSuchMethodException, SecurityException, NoSuchFieldException,
      IllegalArgumentException, IllegalAccessException, InvocationTargetException {
    Scacchiera s = new Scacchiera(true);
    s.getCasella(0, 0).setPezzo(new Torre("bianco"));
    Field scacc = partita.getClass().getDeclaredField("scacchiera");
    scacc.setAccessible(true);
    scacc.set(partita, s);
    Method temp =
        test.getClass().getDeclaredMethod("trovaPezzi", int.class, Pezzo.class, int.class);
    temp.setAccessible(true);
    ArrayList<Posizione> lista =
        (ArrayList<Posizione>) temp.invoke(test, 1, new Torre("bianco"), 1);
    assertTrue(lista.size() == 0);
  }

  @Test
  void trovaUno() throws NoSuchFieldException, SecurityException, IllegalArgumentException,
      IllegalAccessException, NoSuchMethodException, InvocationTargetException {
    Scacchiera s = new Scacchiera(true);
    s.getCasella(0, 0).setPezzo(new Torre("bianco"));
    s.getCasella(0, 7).setPezzo(new Torre("bianco"));
    s.getCasella(0, 4).setPezzo(new Pedone("bianco"));
    Field scacc = partita.getClass().getDeclaredField("scacchiera");
    scacc.setAccessible(true);
    scacc.set(partita, s);
    Method temp =
        test.getClass().getDeclaredMethod("trovaUno", Pezzo.class, Posizione.class, boolean.class);
    temp.setAccessible(true);
    boolean returned = (boolean) temp.invoke(test, new Torre("bianco"), new Posizione(0, 3), true);
    assertTrue(returned);
  }

  @Test
  void trovaUnoFallito() throws NoSuchFieldException, SecurityException, IllegalArgumentException,
      IllegalAccessException, NoSuchMethodException, InvocationTargetException {
    Scacchiera s = new Scacchiera(true);
    s.getCasella(0, 0).setPezzo(new Torre("bianco"));
    s.getCasella(0, 7).setPezzo(new Torre("bianco"));
    Field scacc = partita.getClass().getDeclaredField("scacchiera");
    scacc.setAccessible(true);
    scacc.set(partita, s);
    Method temp =
        test.getClass().getDeclaredMethod("trovaUno", Pezzo.class, Posizione.class, boolean.class);
    temp.setAccessible(true);
    boolean returned = (boolean) temp.invoke(test, new Torre("bianco"), new Posizione(0, 3), true);
    assertFalse(returned);
  }


  @Test
  void testArroccoCortoBianco() throws NoSuchFieldException, SecurityException, IllegalArgumentException,
      IllegalAccessException {
    Scacchiera s = new Scacchiera(true);
    s.getCasella(0, 4).setPezzo(new Re("bianco"));
    s.getCasella(0, 7).setPezzo(new Torre("bianco"));
    Field scacc = partita.getClass().getDeclaredField("scacchiera");
    scacc.setAccessible(true);
    scacc.set(partita, s);
    assertTrue(test.azione("0-0"));
  }

  @Test
  void testArroccoCortoNero() throws NoSuchFieldException, SecurityException, IllegalArgumentException,
      IllegalAccessException {
    Scacchiera s = new Scacchiera(true);
    s.getCasella(7, 4).setPezzo(new Re("nero"));
    s.getCasella(7, 7).setPezzo(new Torre("nero"));
    Field scacc = partita.getClass().getDeclaredField("scacchiera");
    scacc.setAccessible(true);
    scacc.set(partita, s);
    Field turno = partita.getClass().getDeclaredField("turnoBianco");
    turno.setAccessible(true);
    turno.set(partita, false);
    assertTrue(test.azione("0-0"));
  }


  @Test
  void testArroccoCortoMinacciato() throws NoSuchFieldException, SecurityException,
      IllegalArgumentException, IllegalAccessException {
    partita = new Partita();
    Scacchiera s = new Scacchiera(true);
    s.getCasella(0, 4).setPezzo(new Re("bianco"));
    s.getCasella(0, 7).setPezzo(new Torre("bianco"));
    s.getCasella(1, 5).setPezzo(new Torre("nero"));
    Field scacc = partita.getClass().getDeclaredField("scacchiera");
    scacc.setAccessible(true);
    scacc.set(partita, s);
    assertFalse(test.azione("0-0"));
  }


  @Test
  void testArroccoLungoBianco() throws NoSuchFieldException, SecurityException, IllegalArgumentException,
      IllegalAccessException {
    Scacchiera s = new Scacchiera(true);
    s.getCasella(0, 4).setPezzo(new Re("bianco"));
    s.getCasella(0, 0).setPezzo(new Torre("bianco"));
    Field scacc = partita.getClass().getDeclaredField("scacchiera");
    scacc.setAccessible(true);
    scacc.set(partita, s);
    assertTrue(test.azione("0-0-0"));
  }

  @Test
  void testArroccoLungoNero() throws NoSuchFieldException, SecurityException, IllegalArgumentException,
      IllegalAccessException {
    Scacchiera s = new Scacchiera(true);
    s.getCasella(7, 4).setPezzo(new Re("nero"));
    s.getCasella(7, 0).setPezzo(new Torre("nero"));
    Field scacc = partita.getClass().getDeclaredField("scacchiera");
    scacc.setAccessible(true);
    scacc.set(partita, s);
    Field turno = partita.getClass().getDeclaredField("turnoBianco");
    turno.setAccessible(true);
    turno.set(partita, false);
    assertTrue(test.azione("0-0-0"));
  }

  @Test
  void testArroccoLungoMinacciato() throws NoSuchFieldException, SecurityException,
      IllegalArgumentException, IllegalAccessException {
    partita = new Partita();
    Scacchiera s = new Scacchiera(true);
    s.getCasella(0, 4).setPezzo(new Re("bianco"));
    s.getCasella(0, 0).setPezzo(new Torre("bianco"));
    s.getCasella(1, 3).setPezzo(new Torre("nero"));
    Field scacc = partita.getClass().getDeclaredField("scacchiera");
    scacc.setAccessible(true);
    scacc.set(partita, s);
    assertFalse(test.azione("0-0-0"));
  }

}

