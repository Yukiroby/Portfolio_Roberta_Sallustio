package it.uniba.test;

import static org.junit.Assert.assertTrue;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.lang.reflect.InvocationTargetException;

import org.junit.jupiter.api.Test;

import it.uniba.main.AppMain;

public class TestAppMain {

	@Test
    void testSimulazioneMain()
        throws NoSuchMethodException, IllegalAccessException, IllegalArgumentException, InvocationTargetException, NoSuchFieldException, SecurityException, IOException {
      String input = "a4\nplay\ntest\na4\na6\nboard\nmoves\ncaptures\nplay\ntest\nsi\nquit\ntest\nsi";
      InputStream in = new ByteArrayInputStream(input.getBytes("UTF-8"));
      System.setIn(in);
      String[] args = new String[0];
      AppMain.main(args);
      in.close();
      assertTrue(true);
    }
}
