package it.uniba.test;

import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertTrue;
import org.junit.FixMethodOrder;
import org.junit.jupiter.api.Test;
import org.junit.runners.MethodSorters;
import it.uniba.main.Casella;
import it.uniba.main.Pedone;
import it.uniba.main.Scacchiera;

// Running test cases in order of method names in ascending order
@FixMethodOrder(MethodSorters.NAME_ASCENDING)
class TestScacchiera {

  @Test
  void testGetCasella() {
    Scacchiera s = new Scacchiera();
    assertNotNull(s.getCasella(4, 5));
  }

  @Test
  void testGetCasellaOutOfBounds() {
    Scacchiera s = new Scacchiera();
    try {
      Casella c = s.getCasella(9, 9);
      c.setPezzo(new Pedone("bianco"));
    } catch (Exception exception) {
      String indiceOutOfBounds = "9";
      String messaggioErrore = exception.getMessage();
      assertTrue(messaggioErrore.contains(indiceOutOfBounds));
    }
  }
}
