package it.uniba.test;

import static org.junit.jupiter.api.Assertions.assertEquals;

import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import it.uniba.main.Pedone;
import it.uniba.main.Posizione;
import it.uniba.main.Scacchiera;

class TestPedone {

  private Pedone temp;

  @BeforeEach
  void setUp() throws Exception {
    temp = new Pedone("verde");
  }

  @Test
  void testSetColore()
      throws NoSuchFieldException, IllegalArgumentException, IllegalAccessException {
    Field field = temp.getClass().getSuperclass().getDeclaredField("colore");
    field.setAccessible(true);
    assertEquals("bianco", field.get(temp));
  }

  @Test
  void testSetColoreNullo() throws NoSuchFieldException, IllegalArgumentException,
      IllegalAccessException, InvocationTargetException, NoSuchMethodException, SecurityException {
    Method method = temp.getClass().getSuperclass().getDeclaredMethod("setColore", String.class);
    method.setAccessible(true);
    method.invoke(temp, (Object) null);
    Field field = temp.getClass().getSuperclass().getDeclaredField("colore");
    field.setAccessible(true);
    assertEquals("bianco", field.get(temp));
  }

  @Test
  void testSetSimbolo()
      throws NoSuchFieldException, IllegalArgumentException, IllegalAccessException {
    Field field = temp.getClass().getSuperclass().getDeclaredField("simbolo");
    field.setAccessible(true);
    assertEquals("\u2659", field.get(temp));
  }

  @Test
  void testSetSimboloNullo()
      throws NoSuchMethodException, SecurityException, IllegalAccessException,
      IllegalArgumentException, InvocationTargetException, NoSuchFieldException {
    Method method = temp.getClass().getSuperclass().getDeclaredMethod("setSimbolo", String.class);
    method.setAccessible(true);
    method.invoke(temp, (Object) null);
    Field field = temp.getClass().getSuperclass().getDeclaredField("simbolo");
    field.setAccessible(true);
    assertEquals("\u2659", field.get(temp));
  }

  @Test
  void testGetColore() throws IllegalArgumentException, IllegalAccessException,
      NoSuchMethodException, InvocationTargetException {
    Method method = temp.getClass().getSuperclass().getDeclaredMethod("getColore");
    method.setAccessible(true);
    String returned = (String) method.invoke(temp);
    assertEquals("bianco", returned);
  }

  @Test
  void testGetSimbolo() throws IllegalArgumentException, IllegalAccessException,
      NoSuchMethodException, InvocationTargetException {
    Method method = temp.getClass().getSuperclass().getDeclaredMethod("getSimbolo");
    method.setAccessible(true);
    String returned = (String) method.invoke(temp);
    assertEquals("\u2659", returned);
  }

  @Test
  void testColoreDiverso() throws NoSuchMethodException, IllegalAccessException,
      IllegalArgumentException, InvocationTargetException, NoSuchFieldException {
    Method method = temp.getClass().getSuperclass().getDeclaredMethod("setColore", String.class);
    method.setAccessible(true);
    method.invoke(temp, (Object) ("verde"));
    Field field = temp.getClass().getSuperclass().getDeclaredField("colore");
    field.setAccessible(true);
    assertEquals("bianco", field.get(temp));
  }

  @Test
  void testGetPrimaMossaLunga() {

    assertEquals(0, temp.getPrimaMossaLunga());
  }

  @Test
  void testMossaLegaleLungaBianca() {
    Scacchiera scacchiera = new Scacchiera(true);
    scacchiera.getCasella(2, 2).setPezzo(temp);
    assertEquals(true, temp.mossaLegale(scacchiera, new Posizione(2, 2), new Posizione(4, 2)));
  }


  @Test
  void testMossaLegaleLungaNera() {
    Scacchiera scacchiera = new Scacchiera(true);
    scacchiera.getCasella(2, 2).setPezzo(new Pedone("nero"));
    temp = (Pedone) (scacchiera.getCasella(2, 2).getPezzo());
    assertEquals(true, temp.mossaLegale(scacchiera, new Posizione(2, 2), new Posizione(0, 2)));
  }


  @Test
  void testMossaLegaleCortaBianca() throws NoSuchFieldException, SecurityException,
      IllegalArgumentException, IllegalAccessException {
    Scacchiera scacchiera = new Scacchiera(true);
    scacchiera.getCasella(2, 2).setPezzo(temp);
    Field var = temp.getClass().getDeclaredField("primaMossa");
    var.setAccessible(true);
    var.set(temp, false);
    assertEquals(true, temp.mossaLegale(scacchiera, new Posizione(2, 2), new Posizione(3, 2)));
  }


  @Test
  void testMossaLegaleCortaNera() throws NoSuchFieldException, SecurityException,
      IllegalArgumentException, IllegalAccessException {
    Scacchiera scacchiera = new Scacchiera(true);
    scacchiera.getCasella(2, 2).setPezzo(new Pedone("nero"));
    temp = (Pedone) (scacchiera.getCasella(2, 2).getPezzo());
    Field var = temp.getClass().getDeclaredField("primaMossa");
    var.setAccessible(true);
    var.set(temp, false);
    assertEquals(true, temp.mossaLegale(scacchiera, new Posizione(2, 2), new Posizione(1, 2)));
  }

  @Test
  void testMossaIllegale() {
    Scacchiera scacchiera = new Scacchiera(true);
    scacchiera.getCasella(2, 2).setPezzo(temp);
    assertEquals(false, temp.mossaLegale(scacchiera, new Posizione(2, 2), new Posizione(1, 2)));
  }

  @Test
  void testCatturaLegale() {
    Scacchiera scacchiera = new Scacchiera(true);
    scacchiera.getCasella(2, 2).setPezzo(temp);
    scacchiera.getCasella(3, 3).setPezzo(new Pedone("nero"));
    assertEquals(true, temp.catturaLegale(scacchiera, new Posizione(2, 2), new Posizione(3, 3)));
  }

  @Test
  void testCatturaLegaleNonPrimaMossa() throws NoSuchFieldException, SecurityException, IllegalArgumentException, IllegalAccessException {
    Scacchiera scacchiera = new Scacchiera(true);
    scacchiera.getCasella(2, 2).setPezzo(temp);
    scacchiera.getCasella(3, 3).setPezzo(new Pedone("nero"));
    assertEquals(true, scacchiera.getCasella(3, 3).getPezzo().catturaLegale(scacchiera, new Posizione(3, 3), new Posizione(2, 2)));
  }


  @Test
  void testCatturaIllegale() {
    Scacchiera scacchiera = new Scacchiera(true);
    scacchiera.getCasella(2, 2).setPezzo(temp);
    scacchiera.getCasella(3, 3).setPezzo(new Pedone("nero"));
    assertEquals(false, temp.catturaLegale(scacchiera, new Posizione(2, 2),
        new Posizione(Integer.MAX_VALUE, Integer.MIN_VALUE)));
  }

  @Test
  void testEnPassantLegaleBianco()
      throws NoSuchFieldException, IllegalArgumentException, IllegalAccessException {
    Scacchiera scacchiera = new Scacchiera(true);
    scacchiera.getCasella(2, 2).setPezzo(temp);
    scacchiera.getCasella(2, 3).setPezzo(new Pedone("nero"));
    Field field =
        scacchiera.getCasella(2, 3).getPezzo().getClass().getDeclaredField("primaMossaLunga");
    field.setAccessible(true);
    field.setInt(scacchiera.getCasella(2, 3).getPezzo(), -1);
    assertEquals(true,
        (temp).enPassantLegale(scacchiera, new Posizione(2, 2), new Posizione(3, 3)));
  }

  @Test
  void testEnPassantLegaleNero()
      throws NoSuchFieldException, IllegalArgumentException, IllegalAccessException {
    Scacchiera scacchiera = new Scacchiera(true);
    scacchiera.getCasella(2, 2).setPezzo(temp);
    scacchiera.getCasella(2, 3).setPezzo(new Pedone("nero"));
    temp = (Pedone) scacchiera.getCasella(2, 3).getPezzo();
    Field field =
        scacchiera.getCasella(2, 2).getPezzo().getClass().getDeclaredField("primaMossaLunga");
    field.setAccessible(true);
    field.setInt(scacchiera.getCasella(2, 2).getPezzo(), -1);
    assertEquals(true,
        (temp).enPassantLegale(scacchiera, new Posizione(2, 3), new Posizione(1, 2)));
  }

  @Test
  void testEnPassantIllegale()
      throws NoSuchFieldException, IllegalArgumentException, IllegalAccessException {
    Scacchiera scacchiera = new Scacchiera(true);
    scacchiera.getCasella(2, 2).setPezzo(temp);
    scacchiera.getCasella(2, 3).setPezzo(new Pedone("nero"));
    Field field =
        scacchiera.getCasella(2, 3).getPezzo().getClass().getDeclaredField("primaMossaLunga");
    field.setAccessible(true);
    field.setInt(scacchiera.getCasella(2, 3).getPezzo(), -1);
    assertEquals(false,
        (temp).enPassantLegale(scacchiera, new Posizione(2, 2), new Posizione(2, 3)));
  }
}
