package it.uniba.test;

import static org.junit.Assert.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;
import org.junit.jupiter.api.Test;
import it.uniba.main.Posizione;

class TestPosizione {

  @Test
  void testGetColonna() {
    Posizione pos = new Posizione(0, 1);
    assertEquals(1, pos.getColonna());
  }

  @Test
  void testGetRiga() {
    Posizione pos = new Posizione(1, 0);
    assertEquals(1, pos.getRiga());
  }

  @Test
  void testSetColonna() {
    Posizione pos = new Posizione(0, 0);
    pos.setColonna(Integer.MAX_VALUE);
    assertEquals(Integer.MAX_VALUE, pos.getColonna());
  }

  @Test
  void testSetRiga() {
    Posizione pos = new Posizione(0, 0);
    pos.setRiga(Integer.MIN_VALUE);
    assertEquals(Integer.MIN_VALUE, pos.getRiga());
  }

  @Test
  void testEquals() {
    Posizione pos1 = new Posizione(0, 0);
    Posizione pos2 = new Posizione(0, 0);

    assertTrue(pos1.equals(pos2));
  }

  @Test
  void testEqualsStessoOggetto() {
    Posizione pos1 = new Posizione(0, 0);

    assertTrue(pos1.equals(pos1));
  }

  @Test
  void testEqualsOggettoNullo() {
    Posizione pos1 = new Posizione(0, 0);

    assertFalse(pos1.equals(null));
  }

  @Test
  void testEqualsClasseDivesa() {
    Posizione pos1 = new Posizione(0, 0);
    int a = 0;

    assertFalse(pos1.equals(a));
  }

  @Test
  void testEqualsColonnaDiversa() {
    Posizione pos1 = new Posizione(1, 0);
    Posizione pos2 = new Posizione(0, 0);

    assertFalse(pos1.equals(pos2));
  }

  @Test
  void testEqualsRigaDiversa() {
    Posizione pos1 = new Posizione(0, 0);
    Posizione pos2 = new Posizione(0, 1);

    assertFalse(pos1.equals(pos2));
  }

  @Test
  void testHashCode() {
    Posizione pos1 = new Posizione(0, 0);
      assertNotNull(pos1.hashCode());
  }

}
