package it.uniba.test;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import it.uniba.main.GestorePartita;
import it.uniba.main.Partita;

class TestGestorePartita {

	GestorePartita g;

	@BeforeEach
	void setUp() throws Exception {
		g = GestorePartita.getInstance();
	}

	@Test
	void testGetInstance() {
		assertNotNull(g);
	}

	@Test
	void testGetPartita() {
		Partita p = g.getPartita();
		assertNotNull(p);
	}

	@Test
	void testEventoBoard()
			throws NoSuchFieldException, SecurityException, IllegalArgumentException, IllegalAccessException {
		boolean returned = g.evento("board");
		assertTrue(returned);
	}

	@Test
	void testEventoCaptures()
			throws NoSuchFieldException, SecurityException, IllegalArgumentException, IllegalAccessException {
		boolean returned = g.evento("captures");
		assertTrue(returned);
	}

	@Test
	void testEventoMoves()
			throws NoSuchFieldException, SecurityException, IllegalArgumentException, IllegalAccessException {
		boolean returned = g.evento("moves");
		assertTrue(returned);
	}

	@Test
	void testEventoHelp()
			throws NoSuchFieldException, SecurityException, IllegalArgumentException, IllegalAccessException {
		boolean returned = g.evento("help");
		assertTrue(returned);
	}

	@Test
	void testEventoDefault()
			throws NoSuchFieldException, SecurityException, IllegalArgumentException, IllegalAccessException {
		boolean returned = g.evento("test");
		assertFalse(returned);
	}
}
