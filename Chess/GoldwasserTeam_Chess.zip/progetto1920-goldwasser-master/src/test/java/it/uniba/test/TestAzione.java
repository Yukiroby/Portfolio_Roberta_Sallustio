package it.uniba.test;

import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;
import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import org.junit.FixMethodOrder;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.runners.MethodSorters;
import it.uniba.main.Cavallo;
import it.uniba.main.GestoreMovimento;
import it.uniba.main.Partita;
import it.uniba.main.Pedone;
import it.uniba.main.Scacchiera;
import it.uniba.main.Torre;

// Running test cases in order of method names in ascending order
@FixMethodOrder(MethodSorters.NAME_ASCENDING)
class TestAzione {

  private GestoreMovimento test;
  private Field partitaField;
  private Partita partita;

  @BeforeEach
  void setUp() throws Exception {
    test = GestoreMovimento.getInstance();
    partitaField = test.getClass().getDeclaredField("partitaCorrente");
    partitaField.setAccessible(true);
    partitaField.set(test, new Partita());
    partita = (Partita) partitaField.get(test);
    partita.setPartitaIniziata(true);
  }

  @AfterEach
  void tearDown() throws Exception {}

  @Test
  void testMossaCavalloNonDisambiguato() throws NoSuchFieldException, SecurityException,
      IllegalArgumentException, IllegalAccessException {
    partita.setPartitaIniziata(true);
    Scacchiera s = new Scacchiera(true);
    s.getCasella(0, 0).setPezzo(new Cavallo("bianco"));
    Field scacc = partita.getClass().getDeclaredField("scacchiera");
    scacc.setAccessible(true);
    scacc.set(partita, s);
    assertFalse(test.azione("C1c2"));
  }

  @Test
  void testMossaCavallo() throws NoSuchFieldException, SecurityException, IllegalArgumentException,
      IllegalAccessException {
    partita.setPartitaIniziata(true);
    Scacchiera s = new Scacchiera(true);
    s.getCasella(0, 0).setPezzo(new Cavallo("bianco"));
    Field scacc = partita.getClass().getDeclaredField("scacchiera");
    scacc.setAccessible(true);
    scacc.set(partita, s);
    assertTrue(test.azione("Cc2"));
  }


  @Test
  void testCatturaCavallo() throws NoSuchMethodException, SecurityException, IllegalAccessException,
      IllegalArgumentException, InvocationTargetException, NoSuchFieldException {
    partita.setPartitaIniziata(true);
    Scacchiera s = new Scacchiera(true);
    s.getCasella(1, 0).setPezzo(new Cavallo("bianco"));
    s.getCasella(2, 2).setPezzo(new Cavallo("nero"));
    Field scacc = partita.getClass().getDeclaredField("scacchiera");
    scacc.setAccessible(true);
    scacc.set(partita, s);
    assertTrue(test.azione("Cxc3"));
  }

  @Test
  void testCatturaCavalloNonDisambiguato()
      throws NoSuchMethodException, SecurityException, IllegalAccessException,
      IllegalArgumentException, InvocationTargetException, NoSuchFieldException {
    partita.setPartitaIniziata(true);
    Scacchiera s = new Scacchiera(true);
    s.getCasella(0, 0).setPezzo(new Cavallo("bianco"));
    s.getCasella(2, 1).setPezzo(new Cavallo("nero"));
    Field scacc = partita.getClass().getDeclaredField("scacchiera");
    scacc.setAccessible(true);
    scacc.set(partita, s);
    assertFalse(test.azione("C1xc2"));
  }

  @Test
  void testCatturaPedone() throws NoSuchMethodException, SecurityException, IllegalAccessException,
      IllegalArgumentException, InvocationTargetException, NoSuchFieldException {
    partita.setPartitaIniziata(true);
    Scacchiera s = new Scacchiera(true);
    s.getCasella(0, 0).setPezzo(new Pedone("bianco"));
    s.getCasella(1, 1).setPezzo(new Pedone("nero"));
    Field scacc = partita.getClass().getDeclaredField("scacchiera");
    scacc.setAccessible(true);
    scacc.set(partita, s);
    assertTrue(test.azione("axb2"));
  }

  @Test
  void testMossaTorreDisambiguata()
      throws NoSuchMethodException, SecurityException, IllegalAccessException,
      IllegalArgumentException, InvocationTargetException, NoSuchFieldException {
    partita.setPartitaIniziata(true);
    Scacchiera s = new Scacchiera(true);
    s.getCasella(0, 0).setPezzo(new Torre("bianco"));
    s.getCasella(0, 7).setPezzo(new Torre("bianco"));
    Field scacc = partita.getClass().getDeclaredField("scacchiera");
    scacc.setAccessible(true);
    scacc.set(partita, s);
    assertTrue(test.azione("Tac1"));
  }

  @Test
  void testCatturaTorreDisambiguataColonna()
      throws NoSuchMethodException, SecurityException, IllegalAccessException,
      IllegalArgumentException, InvocationTargetException, NoSuchFieldException {
    partita.setPartitaIniziata(true);
    Scacchiera s = new Scacchiera(true);
    s.getCasella(0, 0).setPezzo(new Torre("bianco"));
    s.getCasella(0, 7).setPezzo(new Torre("bianco"));
    s.getCasella(0, 2).setPezzo(new Torre("nero"));
    Field scacc = partita.getClass().getDeclaredField("scacchiera");
    scacc.setAccessible(true);
    scacc.set(partita, s);
    assertTrue(test.azione("Taxc1"));
  }

  @Test
  void testCatturaTorreDisambiguataRiga()
      throws NoSuchMethodException, SecurityException, IllegalAccessException,
      IllegalArgumentException, InvocationTargetException, NoSuchFieldException {
    partita.setPartitaIniziata(true);
    Scacchiera s = new Scacchiera(true);
    s.getCasella(0, 0).setPezzo(new Torre("bianco"));
    s.getCasella(7, 0).setPezzo(new Torre("bianco"));
    s.getCasella(5, 0).setPezzo(new Torre("nero"));
    Field scacc = partita.getClass().getDeclaredField("scacchiera");
    scacc.setAccessible(true);
    scacc.set(partita, s);
    assertTrue(test.azione("T1xa6"));
  }

  @Test
  void testCatturaTorreDisambiguaInadeguata()
      throws NoSuchMethodException, SecurityException, IllegalAccessException,
      IllegalArgumentException, InvocationTargetException, NoSuchFieldException {
    partita.setPartitaIniziata(true);
    Scacchiera s = new Scacchiera(true);
    s.getCasella(0, 0).setPezzo(new Torre("bianco"));
    s.getCasella(0, 7).setPezzo(new Torre("bianco"));
    s.getCasella(0, 2).setPezzo(new Torre("nero"));
    Field scacc = partita.getClass().getDeclaredField("scacchiera");
    scacc.setAccessible(true);
    scacc.set(partita, s);
    assertFalse(test.azione("Txc1"));
  }

  @Test
  void testCatturaEnPassant()
      throws NoSuchMethodException, SecurityException, IllegalAccessException,
      IllegalArgumentException, InvocationTargetException, NoSuchFieldException {
    partita.setPartitaIniziata(true);
    Scacchiera s = new Scacchiera(true);
    s.getCasella(0, 0).setPezzo(new Pedone("bianco"));
    s.getCasella(2, 2).setPezzo(new Pedone("nero"));
    Field scacc = partita.getClass().getDeclaredField("scacchiera");
    scacc.setAccessible(true);
    scacc.set(partita, s);
    assertFalse(test.azione("axb2e.p."));
  }

}
