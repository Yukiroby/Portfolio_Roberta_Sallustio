package it.uniba.test;

import static org.junit.Assert.assertNotEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertEquals;
import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import it.uniba.main.InterfacciaUtente;

class TestInterfacciaUtente {

  InterfacciaUtente i = InterfacciaUtente.getInstance();
  @BeforeEach
  void setUp() throws Exception {
  }

  @AfterEach
  void tearDown() throws Exception {}

  @Test
  void testGetStringaInput() {
	assertNotNull(i.getStringaInput());
  }

  @Test
  void testGetStringaEsci() {
	assertNotNull(i.getEsci());
  }



  @Test
  void testControllaTipo1() throws NoSuchFieldException, IllegalAccessException,
      InvocationTargetException, NoSuchMethodException {
    Field field = i.getClass().getDeclaredField("stringaInput");
    field.setAccessible(true);
    field.set(i, "play");
    Method method = i.getClass().getDeclaredMethod("controlla");
    method.setAccessible(true);
    int returned = (Integer) method.invoke(i);
    assertEquals(1, returned);
  }

  @Test
  void testControllaTipo2() throws NoSuchFieldException, IllegalAccessException,
      InvocationTargetException, NoSuchMethodException {
    Field field = i.getClass().getDeclaredField("stringaInput");
    field.setAccessible(true);
    field.set(i, "0-0-0");
    Method method = i.getClass().getDeclaredMethod("controlla");
    method.setAccessible(true);
    int returned = (Integer) method.invoke(i);
    assertEquals(2, returned);
  }

  @Test
  void testControllaRegex() throws NoSuchFieldException, IllegalAccessException,
      InvocationTargetException, NoSuchMethodException {
    Field field = i.getClass().getDeclaredField("stringaInput");
    field.setAccessible(true);
    field.set(i, "Tz10");
    Method method = i.getClass().getDeclaredMethod("controlla");
    method.setAccessible(true);
    int returned = (Integer) method.invoke(i);
    assertNotEquals(1, returned);
  }

}
