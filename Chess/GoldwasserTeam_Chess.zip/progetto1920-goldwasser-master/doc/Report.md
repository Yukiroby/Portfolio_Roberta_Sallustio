# **RELAZIONE TECNICA**

## **Indice:**

1. **Introduzione**
2. **Modello di dominio**
3. **Requisiti specifici**
    - *Requisiti funzionali*
    - *Requisiti non funzionali*
4. **System Design**
    - *Diagramma dei package*
5. **OO Design**
    - *Diagrammi delle classi e diagrammi di sequenza (per le user story considerate più importanti)*
    - *Applicazione di design pattern*
6. **Riepilogo del test**
    - *Tabella riassuntiva di coveralls (o jacoco), con dati sul numero dei casi di test e copertura del codice*    
7. **Manuale utente**
8. **Processo di sviluppo e organizzazione del lavoro**
9. **Analisi retrospettiva**
    - *Cosa ci ha fatto sentire soddisfatti e ci ha reso contenti*
    - *Cosa ci ha fatto sentire insoddisfatti e ci ha deluso*
    - *Cosa ci ha fatto «impazzire» e ci ha reso disperati*

## **1. Introduzione**
> *"Each game that you play through will be an exciting adventure in chess in which courage, wit, immagination, and ingenuity reap their just reward"* - Irving Chernev

Gli scacchi sono un gioco da tavolo fondato su strategia e abilità logica, nel quale due giocatori muovono 16 pezzi ciascuno, bianchi per l’uno e neri per l’altro, su un quadrante diviso in 64 caselle (chiamato scacchiera), allo scopo di catturare il pezzo principale dell’avversario, il re, con una mossa detta scacco matto. Gli altri pezzi rappresentano 1 donna, 2 torri, 2 alfieri, 2 cavalli e 8 pedoni.

Gli scacchi sono stati sempre molto popolari nell'ambito del gioco da tavolo e addirittura molte persone, per giocare a scacchi a distanza, si spedivano lettere contenenti la loro mossa negli scacchi per la partita che i due stavano svolgendo. Con il progredire della tecnologia anche il gioco degli scacchi è andato incontro ad un'evoluzione, permettendo degli scenari che sarebbero stati altrimenti impossibili. Basti pensare che i ***Computer Scientists dell'IBM*** sono stati interessati al ***Chess Computing*** sin dall'inizio del 1950 e l'11 Maggio 1997 un computer IBM chiamato ***IBM Deep Blue*** ha battuto il campione mondiale di scacchi (Garri Kasparov). 

L'applicazione da noi creata non permette di sfidare un'intelligenza artificiale ma consente:
- Una partita tra due giocatori sulla stessa macchina;
- Un giocatore singolo può giocare contro sé stesso per allenarsi;
- La riproduzione di una partita di giocatori professionisti per studiarla.

Il programma permette di arrivare alla fase della partita che in scacchi è chiamata mediogioco, infatti non è stato implementato lo scacco matto. Tuttavia è comunque possibile svolgere una partita quasi completa.

L'applicazione, realizzata in Java, sfrutta un'interfaccia a linea di comando con caratteri in UTF-8 ed è realizzata seguendo le tecniche di sviluppo agile. In particolare, lo sviluppo del progetto, basato sull'uso del metodo Scrum, è stato strutturato in una serie di iterazioni di durata variabile chiamate *"Sprint"*, in base al carico di lavoro da gestire attraverso il GitHub Flow.

Gli strumenti utilizzati per lo sviluppo del gioco:
- JDK 8;
- Eclipse IDE for Java Developers (2019-12 o superiore);
- JUnit;
- Git e GitHub, per il controllo di versione;
- Docker che permette l'esecuzione del programma in modo indipendente dalla macchina che si sta utilizzando;
- Plugin vari(SpotBugs, CheckStyle, ...).

## **2. Modello di dominio**
Un modello *concettuale* (modello di dominio) è un'astrazione di un sistema sotto studio che potrebbe già essere esistente o lo dovrà essere in futuro.
In sostanza un modello è:
- Un insieme di dichiarazioni riguardanti il sistema sotto studio;
- Un'astrazione di un sistema reale o basato su un linguaggio che consente di fornire un'idea generale;
- Una rappresentazione ridotta di un sistema che evidenzia le proprietà di interesse da un dato punto di vista;
- Una semplificazione di un sistema costruita con l'intento che esso possa rispondere correttamente ai quesiti che gli vengono posti, sostituendosi all'originale.

![modello concettuale](./drawings/diagramma_modello_concettuale.png)

Nel nostro modello di dominio, la *scacchiera* è una composizione di 64 *caselle* ognuna delle quali può contenere un pezzo degli scacchi. Abbiamo un'entità *pezzo* che rappresenta le caratteristiche essenziali di un pezzo degli scacchi, ovvero il suo colore e il simbolo che lo rappresenta, andando, ogni qual volta ne viene rappresentato uno, ad avvalorare queste caratteristiche ed eventualmente aggiungerne delle altre legate al suo comportamento. Infine, è presente un'entità *partita* che rappresenta il match che si sta disputando nel gioco ed in cui è compresa la scacchiera e il relativo stato corrente di quest'ultima.

## **3. Requisiti specifici**

**Requisiti Funzionali**:


Dopo un confronto con il ***product owner*** abbiamo realizzato un *product backlog* contenente diverse ***user story*** riguardanti un unico attore, ovvero il *giocatore*, per il soddisfacimento di determinati requisiti. Per ogni *Sprint* avevamo poi uno *sprint backlog* avente alcune delle *user story*, selezionate appositamente in base all'obiettivo da raggiungere e nel rispetto di determinati *criteri di accettazione*. Queste ultime erano da svolgere in *issues* che dovevano essere portate a termine da al più due membri del team seguendo le modalità dettate dal **GitHub Flow**. In generale, il criterio di accettazione più importante era rispettare le regole degli scacchi.


Durante il *primo sprint* era necessario implementare l'apertura di partita con soli pedoni. Dovevamo realizzare le *user story* del *primo sprint backlog*. Molte delle *user story* di questo *sprint* riguardavano maggiormente il corretto funzionamento dei comandi essenziali dell'applicazione.

 ***"Come giocatore voglio"*** :
- mostrare l'elenco dei comandi;
- iniziare una nuova partita;
- chiudere il gioco;
- mostrare la scacchiera;
- muovere un Pedone (incluso cattura semplice e en passant);
- mostrare le mosse giocate;
- visualizzare le catture.


Nel *secondo sprint* l'obiettivo era di aggiungere la possibilità di arrivare al ***mediogioco***. In modo analogo al *primo sprint*, dovevamo svolgere le *user story* del *secondo sprint backlog*, inoltre bisognava sottolineare il tipo di ogni classe presente nel progetto (<< *Entity* >>, << *Control* >>, << *Boundary* >> , << *noECB* >>) e le relative responsabilità. Le *user story* di questo *sprint*, invece, erano soprattutto improntate all'implementazione delle principali mosse dei pezzi degli scacchi.


***"Come giocatore voglio"*** :
- muovere un Cavallo;
- muovere un Alfiere;
- muovere una Torre;
- muovere la Donna;
- muovere il Re;
- arroccare corto;
- arroccare lungo.

Il terzo e ultimo sprint riguardava la documentazione, in particolar modo l'obiettivo da raggiungere era comunicare la qualità del lavoro che avevamo svolto. Non ci sono state ulteriori *user story* da portare a termine, dovevamo aggiungere dei casi di test automatici attraverso l'utilizzo di *JUnit*, fornire dei commenti appropriati al codice in *JavaDoc* e risolvere dei problemi segnalati da *CheckStyle* e *SpotBugs*.

**Requisiti non funzionali**:
- ***Portabilità***: grazie all'utilizzo di Docker il programma non è legato ad alcuna architettura e può essere eseguito liberamente da qualsiasi macchina;
- ***Correttezza***: il programma genera diversi messaggi di errore per aiutare l'utente a capire in cosa sta sbagliando;
- ***Estendibilità***: suddividendo il software in moduli è facile implementare nuove mosse o pezzi all'interno del gioco (permettendo anche in futuro di lasciare la libertà al giocatore di creare i propri), cambiare l'interfaccia per l'utente passando da una testuale ad una grafica.

## **4. System Design**
**Diagramma dei package**: Non è stato realizzato. Il diagramma dei package non è stato rappresentato poichè abbiamo un solo package nel nostro progetto; ciò deriva da una scelta progettuale dal momento che, essendo un'applicazione piccola, abbiamo deciso di mantenere tutti i file in un unico pacchetto.


## **5. OO Design**
**Diagrammi delle classi e diagrammi di sequenza (per le user story considerate più importanti)**:
Abbiamo scelto le seguenti *user story* per avere una buona copertura delle funzionalità del programma in forma di diagrammi UML. La creazione di una partita è un elemento essenziale ed interagisce con molte delle classi presenti nel programma; il movimento di un alfiere è un ottimo esempio di come vengano gestiti i controlli sulla mossa e la relativa applicazione della stessa al pezzo della scacchiera (tutti i pezzi seguono una logica analoga); l'arrocco corto è un perfetto esempio di come venga svolta la *mossa speciale* più importante del gioco e rappresenta anche il funzionamento della variante lunga avendo entrambi la stessa idea realizzativa.

I diagrammi non rappresentano in modo troppo esplicativo il codice per permettere una migliore comprensione a chi li osserva, lasciando spazio ad una illustrazione più pulita e concettuale, tralasciando metodi, attributi ed eventualmente classi non rilevanti. Si riporta comunque una lista delle differenze più significative:
- Entrambi i diagrammi della creazione di una partita sono stati ridotti. Quando viene creata una partita vengono istanziati anche la scacchiera, le relative caselle e i pezzi che andranno ad occupare alcune di queste ultime. Tuttavia rappresentare questi processi in un diagramma non lo avrebbe reso chiaro andando solamente ad occupare spazio. Abbiamo quindi deciso di lasciare sottointeso che, quando viene iniziata una partita, vengano automaticamente create anche la scacchiera e tutti gli altri oggetti necessari al gioco.
- Il diagramma di sequenza dell'arrocco corto nei controlli è stato estremamente semplificato, se avessimo rappresentato tutti quelli che vengono effettuati in quel metodo, sarebbe stato incomprensibile. Abbiamo quindi deciso di adottare una rappresentazione più semplice raggrupando le condizioni in una sola generica, che riesce comunque a far capire all'osservatore cosa succeda in quella porzione di diagramma.
- Anche il diagramma di sequenza del movimento dell'alfiere è andato incontro ad un processo molto simile a quello dell'arroco corto. Rappresentare tutte le condizioni e i possibili casi nel diagramma avrebbe reso impossibile comprendere il suo contenuto perchè sarebbe diventato troppo caotico. Per evitare questo, abbiamo prima di tutto creato il diagramma intorno all'idea che vogliamo muovere il pezzo e non effettuare una cattura. Il processo di cattura segue le stesse modalità di quello di un normale movimento andando a differenziarsi solo per alcuni controlli, ma il flusso di istruzioni che viene eseguito segue la stessa struttura. Inoltre alcuni controlli sono stati generalizzati nella rappresentazione, per gli stessi motivi dell'arroco.
- Sempre in quest'ultimo diagramma, è stata rappresentata la possibilità che sia necessario specificare una disambiguazione per il movimento. Questo controllo è effettivamente presente nel programma ma, non essendoci la meccanica di promozione del pedone, è impossibile che avvenga dato che due alfieri di un giocatore non incroceranno mai lo stesso percorso (vale lo stesso concetto anche per la donna essendo unica per ogni giocatore). Abbiamo deciso di mantenere comunque quel controllo per tutti i pezzi eccetto i pedoni, sia nel codice sia nel diagramma, prevedendo in un futuro l'aggiunta della promozione del pedone (implementando tale meccanica potrebbero esserci effettivamente dei casi in cui sarà necessario usare la notazione con disambiguazione per alfiere e donna).

**User story: Iniziare una nuova partita**

- Diagramma delle classi:

![diagramma delle classi - iniziare partita](./drawings/classi_inizia_partita.PNG)

- Diagramma di sequenza:

![diagramma di sequenza - iniziare partita](./drawings/sequenza_inizia_partita.PNG)

**User story: Muovere un alfiere**

- Diagramma delle classi:

![diagramma delle classi - muovere alfiere](./drawings/classi_movimento_alfiere.PNG)

- Diagramma di sequenza:

![diagramma di sequenza - muovere alfiere](./drawings/sequenza_movimento_alfiere.PNG)

**User story: Arroccare corto**

- Diagramma delle classi:

![diagramma delle classi - arroccare corto](./drawings/classi_arrocco_corto.PNG)

- Diagramma di sequenza:

![diagramma di sequenza - arroccare corto](./drawings/sequenza_arrocco_corto.PNG)



**Design Pattern adottati**:
- *Singleton*: applicato per le classi che non rappresentano un vero oggetto presente nel gioco, ma che interagiscono con l'utente o modificano lo stato della partita in corso.


## **6. Riepilogo del test**

Riportata la tabella riassuntiva e il link di **Coveralls**, strumento utilizzato per testare le modifiche effettuate sul codice prodotto andando a verificare la sua copertura:

![coveralls](./drawings/jacocoReports/coveralls.PNG)

[Link Coveralls](https://coveralls.io/github/softeng1920-inf-uniba/progetto1920-goldwasser)

Nelle seguenti immagini sono presenti le tabelle riassuntive di **jacoco**:

![scacchi](./drawings/jacocoReports/scacchi.png)
![main](./drawings/jacocoReports/main.png)
![gestore movimento](./drawings/jacocoReports/gestore.png)
![interfaccia utente](./drawings/jacocoReports/interfaccia.png)
![pedone](./drawings/jacocoReports/pedone.png)
![scacchiera](./drawings/jacocoReports/scacchiera.png)
![donna](./drawings/jacocoReports/donna.png)
![torre](./drawings/jacocoReports/torre.png)
![alfiere](./drawings/jacocoReports/alfiere.png)
![scacchiera](./drawings/jacocoReports/scacchiera.png)
![gestore partita](./drawings/jacocoReports/gestorepartita.png)
![partita](./drawings/jacocoReports/partita.png)
![re](./drawings/jacocoReports/re.png)
![posizione](./drawings/jacocoReports/posizione.png)
![cavallo](./drawings/jacocoReports/cavallo.png)
![casella](./drawings/jacocoReports/casella.png)
![pezzo](./drawings/jacocoReports/pezzo.png)
![input tastiera](./drawings/jacocoReports/input.png)
![appmain](./drawings/jacocoReports/appmain.png)

## **7. Manuale Utente**
Come già definito nell'introduzione, l'esecuzione avviene utilizzando docker, attraverso  il seguente comando:

`docker run -it --rm docker.pkg.github.com/softeng1920-inf-uniba/docker_1920/goldwasser`


Appena aperta l'applicazione, viene visualizzato un messaggio di benvenuto per l'utente che lo aiuta ad orientarsi, indicando l'opzione più immediata ovvero "play", oppure suggerisce un comando chiamato *help* per avere una panoramica di tutti i comandi disponibili.
 
Output di help:
`play, board, moves, captures, quit`
 
Digitando il comando `play`, viene cominciata una nuova partita e il programma richiederà all'utente l'inserimento di una mossa o di un ulteriore comando. Nel caso venga inserito nuovamente `play` mentre una partita è già in corso, sarà fornita la possibilità di cominciarne una nuova oppure annullare il comando.
 
Breve descrizione degli altri comandi:
- `board`: stampa a video la scacchiera inclusi i pezzi nelle posizioni occupate nella partita corrente;
- `moves`: stampa uno storico delle mosse effettuate da entrambi i giocatori (`1. e4 e5`, viene indicato il turno con la mossa del bianco seguita dalla mossa del nero);
- `captures`: stampa a video i pezzi catturati da entrambi i giocatore divisi per colore (lista catture bianchi/neri);
- `quit`: permette di uscire dall'applicazione (una conferma è richiesta dopo l'inserimento del comando).
 
Ogni comando è gestito in modo tale che venga eseguito solo se la partita è iniziata o meno. Ad esempio, se l'utente prova ad usare il comando `board` mentre nessuna partita è in corso, allora verrà stampato a video un messaggio di errore `Nessuna partita in corso`. Lo stesso vale per i comandi `moves` e `captures` o per mosse in notazione algebrica, invece i comandi `quit` e `help` sono sempre disponibili. Altri comandi al di fuori di quelli impostati restituiranno un messaggio di errore `Comando non riconosciuto`.
 
L'applicazione è fedele alle regole degli scacchi: per eseguire una mossa è necessario utilizzare la notazione algebrica (non estesa). Se non si è familiari con tale notazione, è possibile informarsi online sul suo utilizzo ([Notazione Algebrica](https://it.wikipedia.org/wiki/Notazione_algebrica)). In caso di uso scorretto o non completo della notazione, esso verrà gestito tramite dei messaggi di errore che notificheranno il giocatore e la mossa non sarà portata a termine, dando la possibilità al giocatore di turno di ripetere la mossa. Inoltre, tutte le scelte opzionali di notazione sono state implementate, ovvero l'en passant può anche essere indicato con i caratteri "e.p." alla fine del comando; l'arrocco può essere indicato usando sia 0 sia O.
 
L'applicazione prevede lo scacco, quindi qualsiasi movimento di pezzi che metterebbe in pericolo il proprio Re viene segnalato come `Mossa illegale: il re sarebbe sotto scacco`. Lo stesso vale se viene mosso un pezzo mentre il Re è sotto scacco e la mossa non mette quest'ultimo fuori pericolo. Tuttavia, non è stata implementata la notazione con il simbolo +, poichè non prevista nelle user story assegnate. Una futura implementazione risulterebbe semplice.
 
**N.B.** : Non è stato ancora implementato lo scacco matto, quindi la partita è potenzialmente infinita, tocca al giocatore, nel caso voglia comunque giocare una partita completa, accorgersi dello scacco matto.


## **8. Processo di Sviluppo e Organizzazione del Lavoro**
Gran parte del lavoro è stato coordinato tramite l'uso del sito **GitHub** che mette a disposizione una metodologia efficiente per il *controllo di versione*. Per il corretto utilizzo della piattaforma è stato anche usato un software chiamato **Git** che permette di caricare e scaricare il progetto dal repository del team. È stato creato un **milestone** associato ad ogni sprint del progetto per suddividere le varie fasi. Sono stati utilizzati al meglio gli strumenti forniti da GitHub, come ad esempio l'uso della **Project Board** (che permette di distribuire e controllare lo stato degli issues), in particolare sono state utilizzate delle board singole per ogni sprint ed una generale di progetto. Tutto il lavoro svolto veniva aggiunto su GitHub attraverso **Pull Request** in modo tale che tutti i componenti del nostro Team potessero visionarlo e dare una loro opinione. Inoltre, quando i cambiamenti erano confermati veniva effettuata in automatico la creazione dell'immagine **Docker** e da quest'ultima verificavamo il corretto funzionamento.
 
Altro strumento molto importante è stata la piattaforma **Microsoft Teams** che ha permesso al nostro team di effettuare dei meeting giornalieri in cui comunicavamo tra noi per mostrare come proseguiva il lavoro di ognuno e proponevamo eventuali idee o migliorie da apportare. Ovviamente, oltre ai meeting giornalieri pianificavamo due ulteriori meeting, uno di "Inizio Sprint" ed uno di "Fine Sprint", il primo per decidere come suddividere il lavoro, mentre il secondo per ricontrollare tutto il progetto ed assicurarci che funzionasse a dovere. Infine, questa piattaforma, nonostante l'emergenza COVID, ci ha permesso di lavorare in **Pair Programming** dal momento che permette di assumere il controllo dello schermo condiviso da una persona.

## **9. Analisi Retrospettiva**
Nel complesso, siamo soddisfatti del nostro lavoro e di come abbiamo gestito lo sviluppo di questa applicazione. Siamo riusciti a gestire bene anche il tempo concessoci continuando sempre a seguire le lezioni in università senza disperarci. È stato un lavoro duro e ha richiesto molta attenzione ma siamo molto soddisfatti del risultato finale. Di seguito un breve riassunto dei punti significativi della nostra esperienza.

**Cosa ci ha fatto sentire soddisfatti e ci ha reso contenti**: come abbiamo organizzato e gestito in modo efficace il lavoro nonostante non avessimo mai lavorato in un team così ampio; l'essere riusciti a raggiungere tutti gli obiettivi entro fine Sprint; l'essere riusciti ad applicare a dovere e con successo tutte le regole degli scacchi riuscendo a replicare alcune famose partite sulla nostra applicazione come *L'Immortale*; l'esperienza del testing ci ha permesso di fare pratica con tecniche avanzate di Java, ad esempio i metodi di *Riflessione* oppure la gestione degli *stream*. 

**Cosa ci ha fatto sentire insoddisfatti e ci ha deluso**: non aver badato troppo ai dettagli fin da subito. 
 
**Cosa ci ha fatto «impazzire» e resi disperati**: trovare una soluzione efficace per l'en passant non è stato semplice da pensare; alcuni casi di test si sono rivelati più complicati del previsto; i diagrammi UML sono risultati ostici a primo impatto.
 
## **Bibliografia**:
- Slides del corso di Ingegneria del Software 19/20;
- **IBM DeepBlue**, https://www.ibm.com/ibm/history/ibm100/us/en/icons/deepblue/
- **Irving Chernev**, *Logical Chess: Move By Move. Every move explained*, **Batsford**, **1998**.
