# TheHeist

Progetto per l'esame di Metodi Avanzati di Programmazione, UniBa, 2019-20.

Gruppo: Diamond Inc.

Autori: Mannavola Matteo, Sallustio Roberta
