package TheHeist;

public interface InterfaceCharacterParameters {
    public String HectorName();
    public String[] HectorAliases();
}
