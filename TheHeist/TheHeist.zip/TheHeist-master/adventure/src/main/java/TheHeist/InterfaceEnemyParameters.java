package TheHeist;

public interface InterfaceEnemyParameters {
    public String cameraName();
    public String[] cameraAliases();
    
    public String guard1Name();
    public String[] guard1Aliases();
    
    public String guard2Name();
    public String[] guard2Aliases();
}
