Green Haven è un serious game realizzato da Mannavola Matteo, Musacchio Elio, Sallustio Roberta, Spinosa Dario per l'esame di Progettazione e Produzione Multimediale, UNIBA 2020/2021.

Obiettivi sul cui si concentra il gioco:
- Città e comunità sostenibili (n° 11)
- Lotta contro il cambiamento climatico (n° 13)
- Energia pulita e accessibile (n° 7)
- Imprese, innovazione e infrastrutture (n° 9)

Tratti dai Sustainable Development Goals delle United Nations.

Maggiori informazioni nel documento di progettazione.
